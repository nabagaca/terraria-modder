using System;
using System.Reflection;
using TerrariaModder.Core.Logging;
using TerrariaModder.Core.UI;

namespace WingSlot
{
    /// <summary>
    /// Draws the dedicated wing slot via FrameEvents.OnUIOverlay.
    /// Appears as a single row below vanilla's last accessory slot with a sky-blue border.
    /// </summary>
    internal static class WingDrawPatches
    {
        private const int SLOT_SIZE = 56;
        private const float EQUIP_SCALE = 0.85f;
        private const int ACCESSORY_OFFSET = 8;
        private const int SOUND_GRAB = 7;
        private const int BORDER_PAD = 2;

        private static bool _anySlotHovered;
        private static int _debugFrames = 120;
        internal static ILogger _log;

        // Cached XNA types
        private static Type _vector2Type;
        private static Type _colorType;
        private static object _whiteColor;

        /// <summary>
        /// The Y position of our wing slot row, exposed so ExtraSlots can position below us.
        /// </summary>
        public static int WingSlotRowY { get; private set; }
        public static int WingSlotRowBottom { get; private set; }
        public static bool IsDrawing { get; private set; }

        public static void OnUIOverlay()
        {
            if (!Mod.Enabled || !WingState.Initialized) return;

            try
            {
                if (Mod.MainPlayerInventory == null || Mod.MainEquipPage == null) return;
                bool inventoryOpen = (bool)Mod.MainPlayerInventory.GetValue(null);
                int equipPage = (int)Mod.MainEquipPage.GetValue(null);
                if (!inventoryOpen || equipPage != 0) return;

                if (Mod.MainIngameOptionsWindow != null && (bool)Mod.MainIngameOptionsWindow.GetValue(null)) return;
                if (Mod.MainInFancyUI != null && (bool)Mod.MainInFancyUI.GetValue(null)) return;

                int screenWidth = (int)Mod.MainScreenWidth.GetValue(null);
                int screenHeight = (int)Mod.MainScreenHeight.GetValue(null);
                int mH = Mod.MainMH != null ? (int)Mod.MainMH.GetValue(null) : 0;

                int myPlayer = (int)Mod.MainMyPlayer.GetValue(null);
                var players = (Array)Mod.MainPlayer.GetValue(null);
                var player = players.GetValue(myPlayer);

                int vanillaExtraSlots = 0;
                if (Mod.PlayerGetExtraSlots != null)
                    vanillaExtraSlots = (int)Mod.PlayerGetExtraSlots.Invoke(player, null);

                int colFunctional = screenWidth - 92;
                int colVanity = screenWidth - 139;
                int colDye = screenWidth - 186;
                int rowHeight = (int)(SLOT_SIZE * EQUIP_SCALE);

                int lastVanillaSlotIndex = 7 + vanillaExtraSlots;
                int baseY = 174 + mH;
                int wingSlotY = baseY + (lastVanillaSlotIndex + 1) * rowHeight + ACCESSORY_OFFSET;

                // Don't draw if off-screen (don't shift up — would cover vanilla)
                if (wingSlotY + rowHeight > screenHeight - 4)
                {
                    IsDrawing = false;
                    return;
                }

                WingSlotRowY = wingSlotY;
                WingSlotRowBottom = wingSlotY + rowHeight;
                IsDrawing = true;

                if (_debugFrames > 0)
                {
                    _debugFrames--;
                    if (_debugFrames == 119)
                        _log?.Info($"[WingDrawPatches] screenW={screenWidth} screenH={screenHeight} mH={mH} vanillaExtra={vanillaExtraSlots} wingSlotY={wingSlotY}");
                }

                _anySlotHovered = false;

                // Draw sky-blue border behind the wing slot row
                int borderX = colDye - BORDER_PAD;
                int borderW = (colFunctional + rowHeight) - borderX + BORDER_PAD;
                int borderH = rowHeight + BORDER_PAD * 2;
                UIRenderer.DrawRect(borderX, wingSlotY - BORDER_PAD, borderW, borderH, 100, 180, 255, 60);

                // Draw the 3 slots
                DrawSingleSlot(colFunctional, wingSlotY, WingState.WingFunctional, 10);
                DrawSingleSlot(colVanity, wingSlotY, WingState.WingVanity, 11);
                DrawSingleSlot(colDye, wingSlotY, WingState.WingDye, 12);

                // Draw eye icon
                DrawEyeIcon(screenWidth, wingSlotY, WingState.WingHide);

                // Handle clicks
                var funcRef = WingState.WingFunctional;
                var vanRef = WingState.WingVanity;
                var dyeRef = WingState.WingDye;

                HandleSlotClick(colFunctional, wingSlotY, ref funcRef, player, ClickMode.Wing);
                HandleSlotClick(colVanity, wingSlotY, ref vanRef, player, ClickMode.WingVanity);
                HandleSlotClick(colDye, wingSlotY, ref dyeRef, player, ClickMode.Dye);

                WingState.WingFunctional = funcRef;
                WingState.WingVanity = vanRef;
                WingState.WingDye = dyeRef;

                bool hideRef = WingState.WingHide;
                HandleEyeClick(screenWidth, wingSlotY, ref hideRef);
                WingState.WingHide = hideRef;

                if (_anySlotHovered && Mod.PlayerMouseInterface != null)
                {
                    Mod.PlayerMouseInterface.SetValue(player, true);
                }
            }
            catch (Exception ex)
            {
                if (_debugFrames > 0)
                    _log?.Error($"[WingDrawPatches] OnUIOverlay error: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private static void DrawSingleSlot(int x, int y, object item, int context)
        {
            if (Mod.ItemSlotDrawArray == null || Mod.MainSpriteBatch == null || Mod.MainInventoryScale == null) return;

            float prevScale = (float)Mod.MainInventoryScale.GetValue(null);
            Mod.MainInventoryScale.SetValue(null, EQUIP_SCALE);
            try
            {
                EnsureSlotBuffer();
                _slotBuffer.SetValue(item, 0);

                EnsureXnaTypesCache();
                var position = Activator.CreateInstance(_vector2Type, new object[] { (float)x, (float)y });

                var spriteBatch = Mod.MainSpriteBatch.GetValue(null);
                Mod.ItemSlotDrawArray.Invoke(null, new object[] { spriteBatch, _slotBuffer, context, 0, position, _whiteColor });
            }
            catch (Exception) { }
            finally
            {
                Mod.MainInventoryScale.SetValue(null, prevScale);
            }
        }

        private static Array _slotBuffer;
        private static void EnsureSlotBuffer()
        {
            if (_slotBuffer == null)
                _slotBuffer = Array.CreateInstance(Mod.ItemType, 1);
        }

        private static void EnsureXnaTypesCache()
        {
            if (_vector2Type != null) return;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                _vector2Type = _vector2Type ?? asm.GetType("Microsoft.Xna.Framework.Vector2");
                _colorType = _colorType ?? asm.GetType("Microsoft.Xna.Framework.Color");
                if (_vector2Type != null && _colorType != null) break;
            }
            if (_colorType != null)
                _whiteColor = _colorType.GetProperty("White", BindingFlags.Public | BindingFlags.Static)?.GetValue(null)
                    ?? Activator.CreateInstance(_colorType);
        }

        private enum ClickMode { Wing, WingVanity, Dye }

        private static void SetHoverText(string text)
        {
            if (Mod.MainHoverItemName != null && Mod.MainMouseText != null)
            {
                Mod.MainHoverItemName.SetValue(null, text);
                Mod.MainMouseText.SetValue(null, true);
            }
        }

        private static string GetSlotTooltip(ClickMode mode)
        {
            switch (mode)
            {
                case ClickMode.Wing: return "Wing Slot";
                case ClickMode.WingVanity: return "Wing Vanity";
                case ClickMode.Dye: return "Wing Dye";
                default: return "";
            }
        }

        private static void HandleSlotClick(int x, int y, ref object slotItem, object player, ClickMode mode)
        {
            if (Mod.MainMouseX == null || Mod.MainMouseY == null) return;

            int mouseX = (int)Mod.MainMouseX.GetValue(null);
            int mouseY = (int)Mod.MainMouseY.GetValue(null);
            int slotSize = (int)(SLOT_SIZE * EQUIP_SCALE);

            if (mouseX < x || mouseX >= x + slotSize || mouseY < y || mouseY >= y + slotSize)
                return;

            _anySlotHovered = true;

            if (WingState.IsAir(slotItem))
                SetHoverText(GetSlotTooltip(mode));

            bool mouseLeft = (bool)Mod.MainMouseLeft.GetValue(null);
            bool mouseLeftRelease = (bool)Mod.MainMouseLeftRelease.GetValue(null);

            if (mouseLeft && mouseLeftRelease)
            {
                Mod.MainMouseLeftRelease.SetValue(null, false);

                var mouseItem = Mod.MainMouseItem.GetValue(null);
                bool mouseIsAir = WingState.IsAir(mouseItem);

                if (mouseIsAir && WingState.IsAir(slotItem))
                    return;

                if (!mouseIsAir && !ValidateItem(mouseItem, mode, player))
                {
                    _log?.Info($"[WingDrawPatches] Validation failed: mode={mode} itemType={WingState.GetItemType(mouseItem)} isWing={WingState.IsWing(mouseItem)} isAccessory={WingState.IsAccessory(mouseItem)}");
                    return;
                }

                var temp = slotItem;
                slotItem = mouseIsAir ? WingState.CreateAirItem() : mouseItem;
                Mod.MainMouseItem.SetValue(null, WingState.IsAir(temp) ? WingState.CreateAirItem() : temp);

                PlayEquipSound();
            }

            bool mouseRight = (bool)Mod.MainMouseRight.GetValue(null);
            bool mouseRightRelease = (bool)Mod.MainMouseRightRelease.GetValue(null);

            if (mouseRight && mouseRightRelease && !WingState.IsAir(slotItem))
            {
                var mouseItem = Mod.MainMouseItem.GetValue(null);
                if (WingState.IsAir(mouseItem))
                {
                    Mod.MainMouseRightRelease.SetValue(null, false);
                    Mod.MainMouseItem.SetValue(null, slotItem);
                    slotItem = WingState.CreateAirItem();
                    PlayEquipSound();
                }
            }
        }

        private static bool ValidateItem(object item, ClickMode mode, object player)
        {
            switch (mode)
            {
                case ClickMode.Wing:
                    // Wing slot only accepts wing items
                    if (!WingState.IsWing(item)) return false;
                    // Wing uniqueness: reject if any wing already equipped anywhere
                    if (IsAnyWingEquippedElsewhere(player)) return false;
                    return !IsDuplicateAccessory(item, player);

                case ClickMode.WingVanity:
                    return WingState.IsWing(item);

                case ClickMode.Dye:
                    return true;

                default:
                    return true;
            }
        }

        private static bool IsDuplicateAccessory(object item, object player)
        {
            if (Mod.ItemTypeField == null) return false;
            int itemType = (int)Mod.ItemTypeField.GetValue(item);
            if (itemType <= 0) return false;

            // Check vanilla armor slots 3-9
            var armor = (Array)Mod.PlayerArmor.GetValue(player);
            if (armor != null)
            {
                for (int i = 3; i < 10; i++)
                {
                    var equipped = armor.GetValue(i);
                    if (!WingState.IsAir(equipped) && (int)Mod.ItemTypeField.GetValue(equipped) == itemType)
                        return true;
                }
            }

            // Cross-mod: check ExtraSlots if loaded
            if (CrossModCompat.GetExtraSlotsEquippedTypes()?.Contains(itemType) == true)
                return true;

            return false;
        }

        /// <summary>
        /// Returns true if any wing is equipped in vanilla slots or ExtraSlots.
        /// Doesn't check the wing slot itself (that's the slot being equipped into).
        /// </summary>
        private static bool IsAnyWingEquippedElsewhere(object player)
        {
            // Check vanilla armor slots 3-9
            var armor = (Array)Mod.PlayerArmor.GetValue(player);
            if (armor != null && Mod.ItemWingSlotField != null)
            {
                for (int i = 3; i < 10; i++)
                {
                    var equipped = armor.GetValue(i);
                    if (!WingState.IsAir(equipped))
                    {
                        sbyte ws = (sbyte)Mod.ItemWingSlotField.GetValue(equipped);
                        if (ws > 0) return true;
                    }
                }
            }

            // Cross-mod: check ExtraSlots
            if (CrossModCompat.HasExtraSlotsWing())
                return true;

            return false;
        }

        private static void DrawEyeIcon(int screenWidth, int slotY, bool hideFlag)
        {
            if (Mod.TickOnField == null || Mod.TickOffField == null) return;

            try
            {
                int iconX = screenWidth - 58;
                int iconY = slotY + (int)(SLOT_SIZE * EQUIP_SCALE * 0.25f);

                var tickAsset = hideFlag ? Mod.TickOffField.GetValue(null) : Mod.TickOnField.GetValue(null);
                if (tickAsset == null) return;

                var valueProp = tickAsset.GetType().GetProperty("Value");
                var texture = valueProp?.GetValue(tickAsset);
                if (texture == null) return;

                var widthProp = texture.GetType().GetProperty("Width");
                var heightProp = texture.GetType().GetProperty("Height");
                int iconW = widthProp != null ? (int)widthProp.GetValue(texture) : 16;
                int iconH = heightProp != null ? (int)heightProp.GetValue(texture) : 16;

                UIRenderer.DrawTexture(texture, iconX, iconY, iconW, iconH, (byte)178);
            }
            catch (Exception) { }
        }

        private static void HandleEyeClick(int screenWidth, int slotY, ref bool hideFlag)
        {
            if (Mod.TickOnField == null || Mod.TickOffField == null) return;
            if (Mod.MainMouseX == null || Mod.MainMouseY == null) return;

            try
            {
                int iconX = screenWidth - 58;
                int iconY = slotY + (int)(SLOT_SIZE * EQUIP_SCALE * 0.25f);

                var tickAsset = hideFlag ? Mod.TickOffField.GetValue(null) : Mod.TickOnField.GetValue(null);
                if (tickAsset == null) return;

                var valueProp = tickAsset.GetType().GetProperty("Value");
                var texture = valueProp?.GetValue(tickAsset);
                if (texture == null) return;

                var widthProp = texture.GetType().GetProperty("Width");
                var heightProp = texture.GetType().GetProperty("Height");
                int iconW = widthProp != null ? (int)widthProp.GetValue(texture) : 16;
                int iconH = heightProp != null ? (int)heightProp.GetValue(texture) : 16;

                int mouseX = (int)Mod.MainMouseX.GetValue(null);
                int mouseY = (int)Mod.MainMouseY.GetValue(null);

                if (mouseX >= iconX && mouseX < iconX + iconW && mouseY >= iconY && mouseY < iconY + iconH)
                {
                    _anySlotHovered = true;

                    bool mouseLeft = (bool)Mod.MainMouseLeft.GetValue(null);
                    bool mouseLeftRelease = (bool)Mod.MainMouseLeftRelease.GetValue(null);

                    var mouseItem = Mod.MainMouseItem.GetValue(null);
                    if (mouseLeft && mouseLeftRelease && WingState.IsAir(mouseItem))
                    {
                        Mod.MainMouseLeftRelease.SetValue(null, false);
                        hideFlag = !hideFlag;
                    }
                }
            }
            catch (Exception) { }
        }

        private static void PlayEquipSound()
        {
            if (Mod.PlaySoundMethod == null) return;
            try
            {
                var parms = Mod.PlaySoundMethod.GetParameters();
                if (parms.Length == 6)
                    Mod.PlaySoundMethod.Invoke(null, new object[] { SOUND_GRAB, -1, -1, 1, 1f, 0f });
                else if (parms.Length >= 1)
                {
                    var args = new object[parms.Length];
                    args[0] = SOUND_GRAB;
                    for (int i = 1; i < args.Length; i++)
                        args[i] = parms[i].HasDefaultValue ? parms[i].DefaultValue : null;
                    Mod.PlaySoundMethod.Invoke(null, args);
                }
            }
            catch (Exception) { }
        }
    }
}
