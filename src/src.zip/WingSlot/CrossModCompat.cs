using System;
using System.Collections.Generic;
using System.Reflection;

namespace WingSlot
{
    /// <summary>
    /// Cross-mod compatibility — discovers ExtraSlots mod's APIs at runtime
    /// to prevent duplicate accessories and enforce wing uniqueness.
    /// </summary>
    internal static class CrossModCompat
    {
        private static MethodInfo _extraSlotsGetEquippedTypes;
        private static MethodInfo _extraSlotsHasWingEquipped;
        private static bool _searched;

        private static void Search()
        {
            if (_searched) return;
            _searched = true;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                var modType = asm.GetType("ExtraSlots.Mod");
                if (modType != null)
                {
                    _extraSlotsGetEquippedTypes = modType.GetMethod("GetEquippedTypes",
                        BindingFlags.Public | BindingFlags.Static);
                    _extraSlotsHasWingEquipped = modType.GetMethod("HasWingEquipped",
                        BindingFlags.Public | BindingFlags.Static);
                    break;
                }
            }
        }

        /// <summary>
        /// Returns the set of item types equipped in ExtraSlots, or null if mod not loaded.
        /// </summary>
        public static HashSet<int> GetExtraSlotsEquippedTypes()
        {
            Search();
            if (_extraSlotsGetEquippedTypes == null) return null;

            try
            {
                return _extraSlotsGetEquippedTypes.Invoke(null, null) as HashSet<int>;
            }
            catch { }

            return null;
        }

        /// <summary>
        /// Returns true if any ExtraSlots slot has a wing equipped.
        /// Used to enforce "only one wing total" rule across mods.
        /// </summary>
        public static bool HasExtraSlotsWing()
        {
            Search();
            if (_extraSlotsHasWingEquipped == null) return false;

            try
            {
                return (bool)_extraSlotsHasWingEquipped.Invoke(null, null);
            }
            catch { return false; }
        }
    }
}
