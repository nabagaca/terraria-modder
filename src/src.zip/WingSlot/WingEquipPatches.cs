using System;
using System.Reflection;
using HarmonyLib;
using TerrariaModder.Core.Logging;

namespace WingSlot
{
    /// <summary>
    /// Harmony postfix on Player.UpdateEquips to apply wing flight effects
    /// from the dedicated wing slot.
    /// </summary>
    internal static class WingEquipPatches
    {
        private static ILogger _log;

        public static void Apply(Harmony harmony, ILogger log)
        {
            _log = log;

            var updateEquips = Mod.PlayerType.GetMethod("UpdateEquips", BindingFlags.Public | BindingFlags.Instance);
            if (updateEquips != null)
            {
                var postfix = typeof(WingEquipPatches).GetMethod(nameof(UpdateEquips_Postfix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(updateEquips, postfix: new HarmonyMethod(postfix));
                _log.Info("[WingEquipPatches] UpdateEquips patched");
            }
            else
            {
                _log.Error("[WingEquipPatches] Could not find Player.UpdateEquips");
            }
        }

        private static void UpdateEquips_Postfix(object __instance, int i)
        {
            if (!Mod.Enabled || !WingState.Initialized) return;

            try
            {
                int myPlayer = (int)Mod.MainMyPlayer.GetValue(null);
                if (i != myPlayer) return;

                var wingItem = WingState.WingFunctional;
                if (WingState.IsAir(wingItem)) return;

                int wingSlotValue = WingState.GetWingSlotValue(wingItem);
                if (wingSlotValue <= 0) return;

                // Set wingsLogic (always — controls flight behavior)
                if (Mod.PlayerWingsLogic != null)
                    Mod.PlayerWingsLogic.SetValue(__instance, wingSlotValue);

                // Set wings (visual — respects hide flag)
                if (Mod.PlayerWings != null && !WingState.WingHide)
                    Mod.PlayerWings.SetValue(__instance, wingSlotValue);

                // Apply prefix benefits (reforges)
                if (WingState.IsAccessory(wingItem))
                    Mod.PlayerGrantPrefixBenefits?.Invoke(__instance, new[] { wingItem });

                // Apply equip functional effects via proxy slot
                if (Mod.PlayerApplyEquipFunctional != null && Mod.PlayerHideVisibleAccessory != null)
                {
                    var hideArr = (bool[])Mod.PlayerHideVisibleAccessory.GetValue(__instance);
                    if (hideArr != null && hideArr.Length > 3)
                    {
                        bool originalHide = hideArr[3];
                        hideArr[3] = WingState.WingHide;
                        try
                        {
                            Mod.PlayerApplyEquipFunctional.Invoke(__instance, new object[] { 3, wingItem });
                        }
                        finally
                        {
                            hideArr[3] = originalHide;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _log?.Error($"[WingEquipPatches] UpdateEquips error: {ex.Message}");
            }
        }
    }
}
