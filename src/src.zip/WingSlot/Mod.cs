using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using HarmonyLib;
using TerrariaModder.Core;
using TerrariaModder.Core.Config;
using TerrariaModder.Core.Events;
using TerrariaModder.Core.Logging;
using TerrariaModder.Core.UI;

namespace WingSlot
{
    public class Mod : IMod
    {
        public string Id => "wing-slot";
        public string Name => "Wing Slot";
        public string Version => "1.0.0";

        private ILogger _log;
        private ModContext _context;
        private Harmony _harmony;
        private Timer _patchTimer;
        private readonly object _patchLock = new object();
        private bool _patchesApplied;

        // Config
        internal static bool Enabled;

        // Reflection cache — types
        internal static Type MainType;
        internal static Type PlayerType;
        internal static Type ItemType;
        internal static Type ItemSlotType;
        internal static Type SoundEngineType;
        internal static Type TextureAssetsType;

        // Reflection cache — Main fields
        internal static FieldInfo MainPlayerInventory;
        internal static FieldInfo MainEquipPage;
        internal static FieldInfo MainMyPlayer;
        internal static FieldInfo MainPlayer;
        internal static FieldInfo MainMouseItem;
        internal static FieldInfo MainSpriteBatch;
        internal static FieldInfo MainScreenWidth;
        internal static FieldInfo MainScreenHeight;
        internal static FieldInfo MainMH;
        internal static FieldInfo MainMouseX;
        internal static FieldInfo MainMouseY;
        internal static FieldInfo MainMouseLeft;
        internal static FieldInfo MainMouseLeftRelease;
        internal static FieldInfo MainMouseRight;
        internal static FieldInfo MainMouseRightRelease;
        internal static FieldInfo MainInventoryScale;
        internal static FieldInfo MainIngameOptionsWindow;
        internal static FieldInfo MainInFancyUI;
        internal static FieldInfo MainHoverItemName;
        internal static FieldInfo MainMouseText;

        // Reflection cache — Player fields/methods
        internal static FieldInfo PlayerArmor;
        internal static FieldInfo PlayerDye;
        internal static FieldInfo PlayerHideVisibleAccessory;
        internal static FieldInfo PlayerCurrentLoadoutIndex;
        internal static FieldInfo PlayerMouseInterface;
        internal static FieldInfo PlayerWings;
        internal static FieldInfo PlayerWingsLogic;
        internal static MethodInfo PlayerGetExtraSlots;

        // Reflection cache — Player private methods for equip effects
        internal static MethodInfo PlayerGrantPrefixBenefits;
        internal static MethodInfo PlayerApplyEquipFunctional;

        // Reflection cache — ItemSlot
        internal static MethodInfo ItemSlotDrawArray;

        // Reflection cache — textures
        internal static FieldInfo TickOnField;
        internal static FieldInfo TickOffField;

        // Reflection cache — SoundEngine
        internal static MethodInfo PlaySoundMethod;

        // Reflection cache — Item fields
        internal static FieldInfo ItemTypeField;
        internal static FieldInfo ItemWingSlotField;

        public void Initialize(ModContext context)
        {
            _context = context;
            _log = context.Logger;

            Enabled = context.Config.Get<bool>("enabled", true);

            _log.Info($"[WingSlot] Config: enabled={Enabled}");

            // Always initialize reflection and events so toggling enabled via F6 works
            InitReflection();
            WingState.InitReflection(_log);
            WingState.Initialize();

            _harmony = new Harmony("com.terrariamodder.wingslot");
            _patchTimer = new Timer(ApplyPatches, null, 5000, Timeout.Infinite);

            WingDrawPatches._log = _log;
            FrameEvents.OnUIOverlay += WingDrawPatches.OnUIOverlay;

            _log.Info("[WingSlot] Initialized");
        }

        public void OnWorldLoad()
        {
            if (!Enabled) return;
            if (!WingState.Initialized) WingState.Initialize();
            _log.Info("[WingSlot] World loaded");
        }

        public void OnWorldUnload()
        {
            _log.Info("[WingSlot] World unloaded");
        }

        public void Unload()
        {
            FrameEvents.OnUIOverlay -= WingDrawPatches.OnUIOverlay;

            lock (_patchLock)
            {
                _harmony?.UnpatchAll("com.terrariamodder.wingslot");
                _patchesApplied = false;
            }

            _patchTimer?.Dispose();
            _patchTimer = null;
            _harmony = null;

            WingState.Clear();
            ClearReflectionCache();

            _log.Info("[WingSlot] Unloaded");
        }

        public void OnConfigChanged()
        {
            Enabled = _context.Config.Get<bool>("enabled", true);
            _log.Info($"[WingSlot] Config changed: enabled={Enabled}");
        }

        /// <summary>
        /// Public API for cross-mod compatibility.
        /// </summary>
        public static HashSet<int> GetEquippedTypes()
        {
            var types = new HashSet<int>();
            if (!WingState.Initialized) return types;

            int t = WingState.GetItemType(WingState.WingFunctional);
            if (t > 0) types.Add(t);
            return types;
        }

        /// <summary>
        /// Returns true if the wing slot has a wing item equipped.
        /// Used by ExtraSlots mod to enforce "only one wing total" rule.
        /// </summary>
        public static bool HasWingEquipped()
        {
            if (!WingState.Initialized) return false;
            return !WingState.IsAir(WingState.WingFunctional);
        }

        private void ApplyPatches(object state)
        {
            lock (_patchLock)
            {
                if (_patchesApplied) return;
                _patchesApplied = true;
            }

            if (_harmony == null || PlayerType == null) return;

            try
            {
                WingEquipPatches.Apply(_harmony, _log);
                WingSavePatches.Apply(_harmony, _log);
                _log.Info("[WingSlot] All patches applied");
            }
            catch (Exception ex)
            {
                _log.Error($"[WingSlot] Patch error: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void InitReflection()
        {
            MainType = Type.GetType("Terraria.Main, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Main");
            PlayerType = Type.GetType("Terraria.Player, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Player");
            ItemType = Type.GetType("Terraria.Item, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Item");
            ItemSlotType = Type.GetType("Terraria.UI.ItemSlot, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.UI.ItemSlot");
            SoundEngineType = Type.GetType("Terraria.Audio.SoundEngine, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Audio.SoundEngine");
            TextureAssetsType = Type.GetType("Terraria.GameContent.TextureAssets, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.GameContent.TextureAssets");

            MainPlayerInventory = MainType.GetField("playerInventory", BindingFlags.Public | BindingFlags.Static);
            MainEquipPage = MainType.GetField("EquipPage", BindingFlags.Public | BindingFlags.Static);
            MainMyPlayer = MainType.GetField("myPlayer", BindingFlags.Public | BindingFlags.Static);
            MainPlayer = MainType.GetField("player", BindingFlags.Public | BindingFlags.Static);
            MainMouseItem = MainType.GetField("mouseItem", BindingFlags.Public | BindingFlags.Static);
            MainSpriteBatch = MainType.GetField("spriteBatch", BindingFlags.Public | BindingFlags.Static);
            MainScreenWidth = MainType.GetField("screenWidth", BindingFlags.Public | BindingFlags.Static);
            MainScreenHeight = MainType.GetField("screenHeight", BindingFlags.Public | BindingFlags.Static);
            MainMH = MainType.GetField("mH", BindingFlags.NonPublic | BindingFlags.Static);
            MainMouseX = MainType.GetField("mouseX", BindingFlags.Public | BindingFlags.Static);
            MainMouseY = MainType.GetField("mouseY", BindingFlags.Public | BindingFlags.Static);
            MainMouseLeft = MainType.GetField("mouseLeft", BindingFlags.Public | BindingFlags.Static);
            MainMouseLeftRelease = MainType.GetField("mouseLeftRelease", BindingFlags.Public | BindingFlags.Static);
            MainMouseRight = MainType.GetField("mouseRight", BindingFlags.Public | BindingFlags.Static);
            MainMouseRightRelease = MainType.GetField("mouseRightRelease", BindingFlags.Public | BindingFlags.Static);
            MainInventoryScale = MainType.GetField("inventoryScale", BindingFlags.Public | BindingFlags.Static);
            MainIngameOptionsWindow = MainType.GetField("ingameOptionsWindow", BindingFlags.Public | BindingFlags.Static);
            MainInFancyUI = MainType.GetField("InFancyUI", BindingFlags.Public | BindingFlags.Static);
            MainHoverItemName = MainType.GetField("hoverItemName", BindingFlags.Public | BindingFlags.Static);
            MainMouseText = MainType.GetField("mouseText", BindingFlags.Public | BindingFlags.Static);

            PlayerArmor = PlayerType.GetField("armor", BindingFlags.Public | BindingFlags.Instance);
            PlayerDye = PlayerType.GetField("dye", BindingFlags.Public | BindingFlags.Instance);
            PlayerHideVisibleAccessory = PlayerType.GetField("hideVisibleAccessory", BindingFlags.Public | BindingFlags.Instance);
            PlayerCurrentLoadoutIndex = PlayerType.GetField("CurrentLoadoutIndex", BindingFlags.Public | BindingFlags.Instance);
            PlayerMouseInterface = PlayerType.GetField("mouseInterface", BindingFlags.Public | BindingFlags.Instance);
            PlayerWings = PlayerType.GetField("wings", BindingFlags.Public | BindingFlags.Instance);
            PlayerWingsLogic = PlayerType.GetField("wingsLogic", BindingFlags.Public | BindingFlags.Instance);
            PlayerGetExtraSlots = PlayerType.GetMethod("GetAmountOfExtraAccessorySlotsToShow", BindingFlags.Public | BindingFlags.Instance);

            PlayerGrantPrefixBenefits = PlayerType.GetMethod("GrantPrefixBenefits", BindingFlags.NonPublic | BindingFlags.Instance);
            PlayerApplyEquipFunctional = PlayerType.GetMethod("ApplyEquipFunctional", BindingFlags.NonPublic | BindingFlags.Instance);

            // Find XNA types from loaded assemblies
            Type spriteBatchType = null, vector2Type = null, colorType = null;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                spriteBatchType = spriteBatchType ?? asm.GetType("Microsoft.Xna.Framework.Graphics.SpriteBatch");
                vector2Type = vector2Type ?? asm.GetType("Microsoft.Xna.Framework.Vector2");
                colorType = colorType ?? asm.GetType("Microsoft.Xna.Framework.Color");
                if (spriteBatchType != null && vector2Type != null && colorType != null) break;
            }

            if (ItemSlotType != null && spriteBatchType != null && ItemType != null && vector2Type != null && colorType != null)
            {
                var itemArrayType = ItemType.MakeArrayType();
                ItemSlotDrawArray = ItemSlotType.GetMethod("Draw", new Type[]
                {
                    spriteBatchType, itemArrayType, typeof(int), typeof(int), vector2Type, colorType
                });
            }

            if (TextureAssetsType != null)
            {
                TickOnField = TextureAssetsType.GetField("InventoryTickOn", BindingFlags.Public | BindingFlags.Static);
                TickOffField = TextureAssetsType.GetField("InventoryTickOff", BindingFlags.Public | BindingFlags.Static);
            }

            if (SoundEngineType != null)
            {
                foreach (var m in SoundEngineType.GetMethods(BindingFlags.Public | BindingFlags.Static))
                {
                    if (m.Name != "PlaySound") continue;
                    var parms = m.GetParameters();
                    if (parms.Length >= 1 && parms[0].ParameterType == typeof(int))
                    {
                        PlaySoundMethod = m;
                        break;
                    }
                }
            }

            ItemTypeField = ItemType?.GetField("type", BindingFlags.Public | BindingFlags.Instance);
            ItemWingSlotField = ItemType?.GetField("wingSlot", BindingFlags.Public | BindingFlags.Instance);

            LogReflectionStatus();
        }

        private void LogReflectionStatus()
        {
            int found = 0, missing = 0;
            void Check(string name, object val) { if (val != null) found++; else { missing++; _log.Error($"[WingSlot] Missing: {name}"); } }

            Check("MainType", MainType);
            Check("PlayerType", PlayerType);
            Check("ItemType", ItemType);
            Check("PlayerWings", PlayerWings);
            Check("PlayerWingsLogic", PlayerWingsLogic);
            Check("ItemWingSlotField", ItemWingSlotField);
            Check("PlayerApplyEquipFunctional", PlayerApplyEquipFunctional);
            Check("ItemSlotDrawArray", ItemSlotDrawArray);
            Check("TickOnField", TickOnField);
            Check("PlaySoundMethod", PlaySoundMethod);

            _log.Info($"[WingSlot] Reflection: {found} found, {missing} missing");
        }

        private void ClearReflectionCache()
        {
            MainType = null; PlayerType = null; ItemType = null; ItemSlotType = null;
            SoundEngineType = null; TextureAssetsType = null;
            MainPlayerInventory = null; MainEquipPage = null; MainMyPlayer = null;
            MainPlayer = null; MainMouseItem = null; MainSpriteBatch = null;
            MainScreenWidth = null; MainScreenHeight = null; MainMH = null;
            MainMouseX = null; MainMouseY = null; MainMouseLeft = null;
            MainMouseLeftRelease = null; MainMouseRight = null; MainMouseRightRelease = null;
            MainInventoryScale = null; MainIngameOptionsWindow = null; MainInFancyUI = null;
            MainHoverItemName = null; MainMouseText = null;
            PlayerArmor = null; PlayerDye = null; PlayerHideVisibleAccessory = null;
            PlayerCurrentLoadoutIndex = null;
            PlayerMouseInterface = null; PlayerGetExtraSlots = null;
            PlayerWings = null; PlayerWingsLogic = null;
            PlayerGrantPrefixBenefits = null; PlayerApplyEquipFunctional = null;
            ItemSlotDrawArray = null;
            TickOnField = null; TickOffField = null;
            PlaySoundMethod = null; ItemTypeField = null; ItemWingSlotField = null;
        }
    }
}
