using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HarmonyLib;
using TerrariaModder.Core.Logging;

namespace WingSlot
{
    /// <summary>
    /// Save/load for wing slot items via sidecar JSON file (.plr.wingslot).
    /// Loadout switching postfix on Player.TrySwitchingLoadout.
    /// </summary>
    internal static class WingSavePatches
    {
        private static ILogger _log;
        private static Type _playerFileDataType;

        public static void Apply(Harmony harmony, ILogger log)
        {
            _log = log;

            _playerFileDataType = Type.GetType("Terraria.IO.PlayerFileData, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.IO.PlayerFileData");

            var saveMethod = Mod.PlayerType.GetMethod("SavePlayer", BindingFlags.Public | BindingFlags.Static);
            if (saveMethod != null)
            {
                var prefix = typeof(WingSavePatches).GetMethod(nameof(SavePlayer_Prefix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(saveMethod, prefix: new HarmonyMethod(prefix));
                _log.Info("[WingSavePatches] SavePlayer patched");
            }

            var loadMethod = Mod.PlayerType.GetMethod("LoadPlayer", BindingFlags.Public | BindingFlags.Static);
            if (loadMethod != null)
            {
                var postfix = typeof(WingSavePatches).GetMethod(nameof(LoadPlayer_Postfix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(loadMethod, postfix: new HarmonyMethod(postfix));
                _log.Info("[WingSavePatches] LoadPlayer patched");
            }

            var switchMethod = Mod.PlayerType.GetMethod("TrySwitchingLoadout", BindingFlags.Public | BindingFlags.Instance);
            if (switchMethod != null)
            {
                var postfix = typeof(WingSavePatches).GetMethod(nameof(TrySwitchingLoadout_Postfix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(switchMethod, postfix: new HarmonyMethod(postfix));
                _log.Info("[WingSavePatches] TrySwitchingLoadout patched");
            }
        }

        private static string GetSidecarPath(object playerFileData)
        {
            if (playerFileData == null || _playerFileDataType == null) return null;
            var pathProp = _playerFileDataType.GetProperty("Path", BindingFlags.Public | BindingFlags.Instance);
            string path = pathProp?.GetValue(playerFileData) as string;
            if (string.IsNullOrEmpty(path)) return null;
            return path + ".wingslot";
        }

        private static void SavePlayer_Prefix(object playerFile)
        {
            if (!Mod.Enabled || !WingState.Initialized) return;

            try
            {
                string sidecarPath = GetSidecarPath(playerFile);
                if (sidecarPath == null) return;

                var data = new Dictionary<string, object>();
                data["version"] = 1;
                data["activeLoadoutIndex"] = _previousLoadoutIndex;
                data["functional"] = SerializeItem(WingState.WingFunctional);
                data["vanity"] = SerializeItem(WingState.WingVanity);
                data["dye"] = SerializeItem(WingState.WingDye);
                data["hide"] = WingState.WingHide;

                var loadouts = new List<Dictionary<string, object>>();
                for (int l = 0; l < 3; l++)
                {
                    var loadout = new Dictionary<string, object>();
                    loadout["functional"] = SerializeItem(WingState.LoadoutWingFunctional[l]);
                    loadout["vanity"] = SerializeItem(WingState.LoadoutWingVanity[l]);
                    loadout["dye"] = SerializeItem(WingState.LoadoutWingDye[l]);
                    loadout["hide"] = WingState.LoadoutWingHide[l];
                    loadouts.Add(loadout);
                }
                data["loadouts"] = loadouts;

                string json = SimpleJson.Serialize(data);
                string tmpPath = sidecarPath + ".tmp";
                File.WriteAllText(tmpPath, json);
                if (File.Exists(sidecarPath))
                {
                    string bakPath = sidecarPath + ".bak";
                    if (File.Exists(bakPath)) File.Delete(bakPath);
                    File.Move(sidecarPath, bakPath);
                }
                File.Move(tmpPath, sidecarPath);
                _log?.Info($"[WingSavePatches] Saved to {Path.GetFileName(sidecarPath)}");
            }
            catch (Exception ex)
            {
                _log?.Error($"[WingSavePatches] Save error: {ex.Message}");
            }
        }

        private static void LoadPlayer_Postfix(string playerPath)
        {
            if (!Mod.Enabled) return;

            try
            {
                string sidecarPath = playerPath + ".wingslot";
                if (!File.Exists(sidecarPath))
                {
                    if (File.Exists(sidecarPath + ".bak"))
                        sidecarPath = sidecarPath + ".bak";
                    else
                    {
                        WingState.Initialize();
                        return;
                    }
                }

                string json = File.ReadAllText(sidecarPath);
                var data = SimpleJson.Deserialize(json);
                if (data == null) { WingState.Initialize(); return; }

                WingState.Initialize();
                _previousLoadoutIndex = GetInt(data, "activeLoadoutIndex");

                WingState.WingFunctional = DeserializeItem(GetDict(data, "functional"));
                WingState.WingVanity = DeserializeItem(GetDict(data, "vanity"));
                WingState.WingDye = DeserializeItem(GetDict(data, "dye"));
                WingState.WingHide = GetBool(data, "hide");

                if (data.TryGetValue("loadouts", out var loadoutsObj) && loadoutsObj is List<object> loadoutsList)
                {
                    for (int l = 0; l < Math.Min(loadoutsList.Count, 3); l++)
                    {
                        if (!(loadoutsList[l] is Dictionary<string, object> loadout)) continue;
                        WingState.LoadoutWingFunctional[l] = DeserializeItem(GetDict(loadout, "functional"));
                        WingState.LoadoutWingVanity[l] = DeserializeItem(GetDict(loadout, "vanity"));
                        WingState.LoadoutWingDye[l] = DeserializeItem(GetDict(loadout, "dye"));
                        WingState.LoadoutWingHide[l] = GetBool(loadout, "hide");
                    }
                }

                _log?.Info($"[WingSavePatches] Loaded from {Path.GetFileName(sidecarPath)}");
            }
            catch (Exception ex)
            {
                _log?.Error($"[WingSavePatches] Load error: {ex.Message}");
                WingState.Initialize();
            }
        }

        private static int _previousLoadoutIndex = 0;

        private static void TrySwitchingLoadout_Postfix(object __instance, int loadoutIndex)
        {
            if (!Mod.Enabled || !WingState.Initialized) return;
            try
            {
                int currentIndex = Mod.PlayerCurrentLoadoutIndex != null
                    ? (int)Mod.PlayerCurrentLoadoutIndex.GetValue(__instance) : 0;
                WingState.SwapLoadout(_previousLoadoutIndex, currentIndex);
                _previousLoadoutIndex = currentIndex;
            }
            catch (Exception ex)
            {
                _log?.Error($"[WingSavePatches] Loadout switch error: {ex.Message}");
            }
        }

        private static Dictionary<string, object> SerializeItem(object item)
        {
            var d = new Dictionary<string, object>();
            if (item == null || WingState.IsAir(item)) { d["type"] = 0; d["stack"] = 0; d["prefix"] = 0; return d; }
            d["type"] = WingState.GetItemType(item);
            d["stack"] = WingState.GetItemStack(item);
            d["prefix"] = WingState.GetItemPrefix(item);
            return d;
        }

        private static object DeserializeItem(Dictionary<string, object> d)
        {
            if (d == null) return WingState.CreateAirItem();
            int type = GetInt(d, "type");
            if (type <= 0) return WingState.CreateAirItem();
            return WingState.CreateItem(type, GetInt(d, "stack", 1), GetInt(d, "prefix"));
        }

        private static Dictionary<string, object> GetDict(Dictionary<string, object> d, string key)
        {
            if (d != null && d.TryGetValue(key, out var val) && val is Dictionary<string, object> dict) return dict;
            return null;
        }

        private static int GetInt(Dictionary<string, object> d, string key, int def = 0)
        {
            if (d != null && d.TryGetValue(key, out var val))
            {
                if (val is int i) return i;
                if (val is long l) return (int)l;
                if (val is double dbl) return (int)dbl;
            }
            return def;
        }

        private static bool GetBool(Dictionary<string, object> d, string key, bool def = false)
        {
            if (d != null && d.TryGetValue(key, out var val) && val is bool b) return b;
            return def;
        }
    }

    internal static class SimpleJson
    {
        public static string Serialize(object obj) { var sb = new System.Text.StringBuilder(); SerializeValue(sb, obj); return sb.ToString(); }
        public static Dictionary<string, object> Deserialize(string json) { if (string.IsNullOrEmpty(json)) return null; int i = 0; return ParseObject(json, ref i); }
        private static void SerializeValue(System.Text.StringBuilder sb, object val) { if (val == null) { sb.Append("null"); return; } if (val is bool b) { sb.Append(b ? "true" : "false"); return; } if (val is int ii) { sb.Append(ii); return; } if (val is long l) { sb.Append(l); return; } if (val is double d) { sb.Append(d); return; } if (val is string s) { SerializeString(sb, s); return; } if (val is Dictionary<string, object> dict) { SerializeDict(sb, dict); return; } if (val is System.Collections.IList list) { SerializeList(sb, list); return; } sb.Append(val.ToString()); }
        private static void SerializeString(System.Text.StringBuilder sb, string s) { sb.Append('"'); foreach (char c in s) { switch (c) { case '"': sb.Append("\\\""); break; case '\\': sb.Append("\\\\"); break; case '\n': sb.Append("\\n"); break; case '\r': sb.Append("\\r"); break; case '\t': sb.Append("\\t"); break; default: sb.Append(c); break; } } sb.Append('"'); }
        private static void SerializeDict(System.Text.StringBuilder sb, Dictionary<string, object> dict) { sb.Append('{'); bool first = true; foreach (var kvp in dict) { if (!first) sb.Append(','); first = false; SerializeString(sb, kvp.Key); sb.Append(':'); SerializeValue(sb, kvp.Value); } sb.Append('}'); }
        private static void SerializeList(System.Text.StringBuilder sb, System.Collections.IList list) { sb.Append('['); for (int i = 0; i < list.Count; i++) { if (i > 0) sb.Append(','); SerializeValue(sb, list[i]); } sb.Append(']'); }
        private static Dictionary<string, object> ParseObject(string json, ref int i) { var dict = new Dictionary<string, object>(); SkipWS(json, ref i); if (i >= json.Length || json[i] != '{') return dict; i++; while (i < json.Length) { SkipWS(json, ref i); if (i >= json.Length || json[i] == '}') { i++; return dict; } if (json[i] == ',') { i++; continue; } string key = ParseString(json, ref i); SkipWS(json, ref i); if (i < json.Length && json[i] == ':') i++; SkipWS(json, ref i); dict[key] = ParseValue(json, ref i); } return dict; }
        private static List<object> ParseArray(string json, ref int i) { var list = new List<object>(); i++; while (i < json.Length) { SkipWS(json, ref i); if (i >= json.Length || json[i] == ']') { i++; return list; } if (json[i] == ',') { i++; continue; } list.Add(ParseValue(json, ref i)); } return list; }
        private static object ParseValue(string json, ref int i) { SkipWS(json, ref i); if (i >= json.Length) return null; char c = json[i]; if (c == '"') return ParseString(json, ref i); if (c == '{') return ParseObject(json, ref i); if (c == '[') return ParseArray(json, ref i); if (c == 't') { i += 4; return true; } if (c == 'f') { i += 5; return false; } if (c == 'n') { i += 4; return null; } return ParseNumber(json, ref i); }
        private static string ParseString(string json, ref int i) { if (json[i] != '"') return ""; i++; var sb = new System.Text.StringBuilder(); while (i < json.Length && json[i] != '"') { if (json[i] == '\\' && i + 1 < json.Length) { i++; switch (json[i]) { case '"': sb.Append('"'); break; case '\\': sb.Append('\\'); break; case 'n': sb.Append('\n'); break; case 'r': sb.Append('\r'); break; case 't': sb.Append('\t'); break; default: sb.Append(json[i]); break; } } else sb.Append(json[i]); i++; } if (i < json.Length) i++; return sb.ToString(); }
        private static object ParseNumber(string json, ref int i) { int start = i; bool isFloat = false; if (i < json.Length && json[i] == '-') i++; while (i < json.Length && (char.IsDigit(json[i]) || json[i] == '.' || json[i] == 'e' || json[i] == 'E' || json[i] == '+' || json[i] == '-')) { if (json[i] == '.' || json[i] == 'e' || json[i] == 'E') isFloat = true; i++; } string numStr = json.Substring(start, i - start); if (isFloat) { double.TryParse(numStr, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double dv); return dv; } if (int.TryParse(numStr, out int intVal)) return intVal; if (long.TryParse(numStr, out long longVal)) return longVal; return 0; }
        private static void SkipWS(string json, ref int i) { while (i < json.Length && char.IsWhiteSpace(json[i])) i++; }
    }
}
