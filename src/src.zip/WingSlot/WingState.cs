using System;
using System.Reflection;
using TerrariaModder.Core.Logging;

namespace WingSlot
{
    /// <summary>
    /// Static state for the dedicated wing slot — single functional/vanity/dye/hide set
    /// with per-loadout copies mirroring vanilla's EquipmentLoadout system.
    /// </summary>
    internal static class WingState
    {
        private static ILogger _log;
        private static Type _itemType;
        private static FieldInfo _typeField;
        private static FieldInfo _stackField;
        private static FieldInfo _prefixField;
        private static FieldInfo _accessoryField;
        private static FieldInfo _wingSlotField;
        private static MethodInfo _setDefaultsMethod;
        private static PropertyInfo _isAirProp;

        // Active wing slot
        public static object WingFunctional;
        public static object WingVanity;
        public static object WingDye;
        public static bool WingHide;

        // Per-loadout storage (3 loadouts)
        public static object[] LoadoutWingFunctional;
        public static object[] LoadoutWingVanity;
        public static object[] LoadoutWingDye;
        public static bool[] LoadoutWingHide;

        public static bool Initialized { get; private set; }

        public static void InitReflection(ILogger log)
        {
            _log = log;
            _itemType = Type.GetType("Terraria.Item, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Item");

            if (_itemType == null)
            {
                _log?.Error("[WingState] Could not find Terraria.Item type");
                return;
            }

            _typeField = _itemType.GetField("type", BindingFlags.Public | BindingFlags.Instance);
            _stackField = _itemType.GetField("stack", BindingFlags.Public | BindingFlags.Instance);
            _prefixField = _itemType.GetField("prefix", BindingFlags.Public | BindingFlags.Instance);
            _accessoryField = _itemType.GetField("accessory", BindingFlags.Public | BindingFlags.Instance);
            _wingSlotField = _itemType.GetField("wingSlot", BindingFlags.Public | BindingFlags.Instance);
            _isAirProp = _itemType.GetProperty("IsAir", BindingFlags.Public | BindingFlags.Instance);
            _setDefaultsMethod = _itemType.GetMethod("SetDefaults", new Type[] { typeof(int) });

            _log?.Info("[WingState] Reflection initialized");
        }

        public static void Initialize()
        {
            WingFunctional = CreateAirItem();
            WingVanity = CreateAirItem();
            WingDye = CreateAirItem();
            WingHide = false;

            LoadoutWingFunctional = new object[3];
            LoadoutWingVanity = new object[3];
            LoadoutWingDye = new object[3];
            LoadoutWingHide = new bool[3];

            for (int l = 0; l < 3; l++)
            {
                LoadoutWingFunctional[l] = CreateAirItem();
                LoadoutWingVanity[l] = CreateAirItem();
                LoadoutWingDye[l] = CreateAirItem();
            }

            Initialized = true;
            _log?.Info("[WingState] Initialized");
        }

        public static void SwapLoadout(int fromLoadout, int toLoadout)
        {
            if (fromLoadout < 0 || fromLoadout >= 3 || toLoadout < 0 || toLoadout >= 3) return;

            LoadoutWingFunctional[fromLoadout] = WingFunctional;
            LoadoutWingVanity[fromLoadout] = WingVanity;
            LoadoutWingDye[fromLoadout] = WingDye;
            LoadoutWingHide[fromLoadout] = WingHide;

            WingFunctional = LoadoutWingFunctional[toLoadout];
            WingVanity = LoadoutWingVanity[toLoadout];
            WingDye = LoadoutWingDye[toLoadout];
            WingHide = LoadoutWingHide[toLoadout];

            _log?.Info($"[WingState] Swapped loadout {fromLoadout} -> {toLoadout}");
        }

        public static void Clear()
        {
            WingFunctional = null;
            WingVanity = null;
            WingDye = null;
            WingHide = false;
            LoadoutWingFunctional = null;
            LoadoutWingVanity = null;
            LoadoutWingDye = null;
            LoadoutWingHide = null;
            Initialized = false;
        }

        // --- Item helpers ---

        public static object CreateAirItem()
        {
            if (_itemType == null) return null;
            return Activator.CreateInstance(_itemType);
        }

        public static object CreateItem(int type, int stack = 1, int prefix = 0)
        {
            var item = CreateAirItem();
            if (item == null || _setDefaultsMethod == null) return item;
            _setDefaultsMethod.Invoke(item, new object[] { type });
            if (stack > 1) _stackField?.SetValue(item, stack);
            if (prefix > 0) _prefixField?.SetValue(item, (byte)prefix);
            return item;
        }

        public static bool IsAir(object item)
        {
            if (item == null) return true;
            if (_isAirProp != null) return (bool)_isAirProp.GetValue(item);
            if (_typeField != null) return (int)_typeField.GetValue(item) == 0;
            return true;
        }

        public static int GetItemType(object item)
        {
            if (item == null || _typeField == null) return 0;
            return (int)_typeField.GetValue(item);
        }

        public static int GetItemStack(object item)
        {
            if (item == null || _stackField == null) return 0;
            return (int)_stackField.GetValue(item);
        }

        public static int GetItemPrefix(object item)
        {
            if (item == null || _prefixField == null) return 0;
            return (int)(byte)_prefixField.GetValue(item);
        }

        public static bool IsAccessory(object item)
        {
            if (item == null || _accessoryField == null) return false;
            return (bool)_accessoryField.GetValue(item);
        }

        public static bool IsWing(object item)
        {
            if (item == null || _wingSlotField == null) return false;
            sbyte ws = (sbyte)_wingSlotField.GetValue(item);
            return ws > 0;
        }

        public static int GetWingSlotValue(object item)
        {
            if (item == null || _wingSlotField == null) return 0;
            return (sbyte)_wingSlotField.GetValue(item);
        }
    }
}
