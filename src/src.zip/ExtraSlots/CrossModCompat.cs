using System;
using System.Collections.Generic;
using System.Reflection;

namespace ExtraSlots
{
    /// <summary>
    /// Cross-mod compatibility — discovers WingSlot mod's APIs at runtime
    /// to prevent duplicate accessories and enforce wing uniqueness.
    /// </summary>
    internal static class CrossModCompat
    {
        private static MethodInfo _wingSlotGetEquippedTypes;
        private static MethodInfo _wingSlotHasWingEquipped;
        private static bool _searched;

        private static void Search()
        {
            if (_searched) return;
            _searched = true;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                var modType = asm.GetType("WingSlot.Mod");
                if (modType != null)
                {
                    _wingSlotGetEquippedTypes = modType.GetMethod("GetEquippedTypes",
                        BindingFlags.Public | BindingFlags.Static);
                    _wingSlotHasWingEquipped = modType.GetMethod("HasWingEquipped",
                        BindingFlags.Public | BindingFlags.Static);
                    break;
                }
            }
        }

        /// <summary>
        /// Returns the item type equipped in the WingSlot mod's wing slot, or 0 if not found.
        /// </summary>
        public static int GetWingSlotEquippedType()
        {
            Search();
            if (_wingSlotGetEquippedTypes == null) return 0;

            try
            {
                var types = _wingSlotGetEquippedTypes.Invoke(null, null) as HashSet<int>;
                if (types != null)
                {
                    foreach (int t in types) return t; // Wing slot has at most 1 item
                }
            }
            catch { }

            return 0;
        }

        /// <summary>
        /// Returns true if the WingSlot mod has a wing equipped.
        /// Used to enforce "only one wing total" rule across mods.
        /// </summary>
        public static bool IsWingSlotOccupied()
        {
            Search();
            if (_wingSlotHasWingEquipped == null) return false;

            try
            {
                return (bool)_wingSlotHasWingEquipped.Invoke(null, null);
            }
            catch { return false; }
        }
    }
}
