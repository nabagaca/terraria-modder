using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using HarmonyLib;
using TerrariaModder.Core;
using TerrariaModder.Core.Config;
using TerrariaModder.Core.Events;
using TerrariaModder.Core.Logging;
using TerrariaModder.Core.UI;

namespace ExtraSlots
{
    public class Mod : IMod
    {
        public string Id => "extra-slots";
        public string Name => "Extra Slots";
        public string Version => "1.0.0";

        private ILogger _log;
        private ModContext _context;
        private Harmony _harmony;
        private Timer _patchTimer;
        private readonly object _patchLock = new object();
        private bool _patchesApplied;

        // Config
        internal static bool Enabled;
        internal static int ExtraSlotCount;
        private int _prevExtraSlotCount;

        // Reflection cache — types
        internal static Type MainType;
        internal static Type PlayerType;
        internal static Type ItemType;
        internal static Type ItemSlotType;
        internal static Type SoundEngineType;
        internal static Type TextureAssetsType;

        // Reflection cache — Main fields
        internal static FieldInfo MainPlayerInventory;
        internal static FieldInfo MainEquipPage;
        internal static FieldInfo MainMyPlayer;
        internal static FieldInfo MainPlayer;
        internal static FieldInfo MainMouseItem;
        internal static FieldInfo MainSpriteBatch;
        internal static FieldInfo MainScreenWidth;
        internal static FieldInfo MainScreenHeight;
        internal static FieldInfo MainMH;
        internal static FieldInfo MainMouseX;
        internal static FieldInfo MainMouseY;
        internal static FieldInfo MainMouseLeft;
        internal static FieldInfo MainMouseLeftRelease;
        internal static FieldInfo MainMouseRight;
        internal static FieldInfo MainMouseRightRelease;
        internal static FieldInfo MainInventoryScale;
        internal static FieldInfo MainIngameOptionsWindow;
        internal static FieldInfo MainInFancyUI;
        internal static FieldInfo MainHoverItemName;
        internal static FieldInfo MainMouseText;

        // Reflection cache — Player fields/methods
        internal static FieldInfo PlayerArmor;
        internal static FieldInfo PlayerDye;
        internal static FieldInfo PlayerHideVisibleAccessory;
        internal static FieldInfo PlayerCurrentLoadoutIndex;
        internal static FieldInfo PlayerMouseInterface;
        internal static FieldInfo PlayerWings;
        internal static FieldInfo PlayerWingsLogic;
        internal static MethodInfo PlayerGetExtraSlots;

        // Reflection cache — Player private methods for equip effects
        internal static MethodInfo PlayerGrantPrefixBenefits;
        internal static MethodInfo PlayerGrantArmorBenefits;
        internal static MethodInfo PlayerApplyEquipFunctional;
        internal static MethodInfo PlayerApplyEquipVanity;
        internal static MethodInfo PlayerUpdateVisibleAccessories;

        // Reflection cache — ItemSlot
        internal static MethodInfo ItemSlotDrawArray;

        // Reflection cache — textures
        internal static FieldInfo TickOnField;
        internal static FieldInfo TickOffField;

        // Reflection cache — SoundEngine
        internal static MethodInfo PlaySoundMethod;

        // Reflection cache — Item fields
        internal static FieldInfo ItemTypeField;
        internal static FieldInfo ItemWingSlotField;

        public void Initialize(ModContext context)
        {
            _context = context;
            _log = context.Logger;

            Enabled = context.Config.Get<bool>("enabled", true);
            ExtraSlotCount = Math.Max(0, context.Config.Get<int>("extraSlots", 0));
            _prevExtraSlotCount = ExtraSlotCount;

            _log.Info($"[ExtraSlots] Config: enabled={Enabled}, extraSlots={ExtraSlotCount}");

            // Always initialize reflection and events so toggling enabled via F6 works
            InitReflection();
            SlotState.InitReflection(_log);
            SlotState.Initialize(ExtraSlotCount);

            _harmony = new Harmony("com.terrariamodder.extraslots");
            _patchTimer = new Timer(ApplyPatches, null, 5000, Timeout.Infinite);

            DrawPatches._log = _log;
            FrameEvents.OnUIOverlay += DrawPatches.OnUIOverlay;

            _log.Info("[ExtraSlots] Initialized");
        }

        public void OnWorldLoad()
        {
            if (!Enabled) return;
            if (!SlotState.Initialized) SlotState.Initialize(ExtraSlotCount);
            _log.Info("[ExtraSlots] World loaded");
        }

        public void OnWorldUnload()
        {
            _log.Info("[ExtraSlots] World unloaded");
        }

        public void Unload()
        {
            FrameEvents.OnUIOverlay -= DrawPatches.OnUIOverlay;

            lock (_patchLock)
            {
                _harmony?.UnpatchAll("com.terrariamodder.extraslots");
                _patchesApplied = false;
            }

            _patchTimer?.Dispose();
            _patchTimer = null;
            _harmony = null;

            SlotState.Clear();
            ClearReflectionCache();

            _log.Info("[ExtraSlots] Unloaded");
        }

        public void OnConfigChanged()
        {
            bool newEnabled = _context.Config.Get<bool>("enabled", true);
            int newExtraSlots = Math.Max(0, _context.Config.Get<int>("extraSlots", 0));

            if (newExtraSlots != _prevExtraSlotCount)
            {
                var displaced = SlotState.Resize(newExtraSlots);
                HandleDisplacedItems(displaced);
                _prevExtraSlotCount = newExtraSlots;
                ExtraSlotCount = newExtraSlots;
                _log.Info($"[ExtraSlots] Extra slots changed to {newExtraSlots}");
            }

            Enabled = newEnabled;
        }

        /// <summary>
        /// Public API for cross-mod compatibility.
        /// </summary>
        public static HashSet<int> GetEquippedTypes()
        {
            var types = new HashSet<int>();
            if (!SlotState.Initialized) return types;

            for (int i = 0; i < SlotState.SlotCount; i++)
            {
                int t = SlotState.GetItemType(SlotState.ExtraFunctional[i]);
                if (t > 0) types.Add(t);
            }
            return types;
        }

        /// <summary>
        /// Returns true if any extra slot has a wing item equipped (wingSlot > 0).
        /// Used by WingSlot mod to enforce "only one wing total" rule.
        /// </summary>
        public static bool HasWingEquipped()
        {
            if (!SlotState.Initialized) return false;
            for (int i = 0; i < SlotState.SlotCount; i++)
            {
                if (!SlotState.IsAir(SlotState.ExtraFunctional[i]) && SlotState.GetWingSlot(SlotState.ExtraFunctional[i]) > 0)
                    return true;
            }
            return false;
        }

        internal void HandleDisplacedItems(object[] items)
        {
            if (items == null || items.Length == 0) return;

            try
            {
                int myPlayer = (int)MainMyPlayer.GetValue(null);
                var players = (Array)MainPlayer.GetValue(null);
                var player = players.GetValue(myPlayer);

                var inventory = (Array)PlayerType.GetField("inventory", BindingFlags.Public | BindingFlags.Instance)
                    ?.GetValue(player);
                if (inventory == null) return;

                foreach (var item in items)
                {
                    if (SlotState.IsAir(item)) continue;
                    bool placed = false;

                    for (int i = 0; i < 50; i++)
                    {
                        var slot = inventory.GetValue(i);
                        if (SlotState.IsAir(slot))
                        {
                            inventory.SetValue(item, i);
                            placed = true;
                            break;
                        }
                    }

                    if (!placed)
                        _log.Info($"[ExtraSlots] Could not place displaced item type={SlotState.GetItemType(item)} in inventory (full)");
                }
            }
            catch (Exception ex)
            {
                _log.Error($"[ExtraSlots] HandleDisplacedItems error: {ex.Message}");
            }
        }

        private void ApplyPatches(object state)
        {
            lock (_patchLock)
            {
                if (_patchesApplied) return;
                _patchesApplied = true;
            }

            if (_harmony == null || PlayerType == null) return;

            try
            {
                EquipEffectPatches.Apply(_harmony, _log);
                SaveLoadPatches.Apply(_harmony, _log);
                PanelShiftPatch.Apply(_harmony, _log);
                _log.Info("[ExtraSlots] All patches applied");
            }
            catch (Exception ex)
            {
                _log.Error($"[ExtraSlots] Patch error: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private void InitReflection()
        {
            MainType = Type.GetType("Terraria.Main, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Main");
            PlayerType = Type.GetType("Terraria.Player, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Player");
            ItemType = Type.GetType("Terraria.Item, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Item");
            ItemSlotType = Type.GetType("Terraria.UI.ItemSlot, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.UI.ItemSlot");
            SoundEngineType = Type.GetType("Terraria.Audio.SoundEngine, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Audio.SoundEngine");
            TextureAssetsType = Type.GetType("Terraria.GameContent.TextureAssets, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.GameContent.TextureAssets");

            MainPlayerInventory = MainType.GetField("playerInventory", BindingFlags.Public | BindingFlags.Static);
            MainEquipPage = MainType.GetField("EquipPage", BindingFlags.Public | BindingFlags.Static);
            MainMyPlayer = MainType.GetField("myPlayer", BindingFlags.Public | BindingFlags.Static);
            MainPlayer = MainType.GetField("player", BindingFlags.Public | BindingFlags.Static);
            MainMouseItem = MainType.GetField("mouseItem", BindingFlags.Public | BindingFlags.Static);
            MainSpriteBatch = MainType.GetField("spriteBatch", BindingFlags.Public | BindingFlags.Static);
            MainScreenWidth = MainType.GetField("screenWidth", BindingFlags.Public | BindingFlags.Static);
            MainScreenHeight = MainType.GetField("screenHeight", BindingFlags.Public | BindingFlags.Static);
            MainMH = MainType.GetField("mH", BindingFlags.NonPublic | BindingFlags.Static);
            MainMouseX = MainType.GetField("mouseX", BindingFlags.Public | BindingFlags.Static);
            MainMouseY = MainType.GetField("mouseY", BindingFlags.Public | BindingFlags.Static);
            MainMouseLeft = MainType.GetField("mouseLeft", BindingFlags.Public | BindingFlags.Static);
            MainMouseLeftRelease = MainType.GetField("mouseLeftRelease", BindingFlags.Public | BindingFlags.Static);
            MainMouseRight = MainType.GetField("mouseRight", BindingFlags.Public | BindingFlags.Static);
            MainMouseRightRelease = MainType.GetField("mouseRightRelease", BindingFlags.Public | BindingFlags.Static);
            MainInventoryScale = MainType.GetField("inventoryScale", BindingFlags.Public | BindingFlags.Static);
            MainIngameOptionsWindow = MainType.GetField("ingameOptionsWindow", BindingFlags.Public | BindingFlags.Static);
            MainInFancyUI = MainType.GetField("InFancyUI", BindingFlags.Public | BindingFlags.Static);
            MainHoverItemName = MainType.GetField("hoverItemName", BindingFlags.Public | BindingFlags.Static);
            MainMouseText = MainType.GetField("mouseText", BindingFlags.Public | BindingFlags.Static);

            PlayerArmor = PlayerType.GetField("armor", BindingFlags.Public | BindingFlags.Instance);
            PlayerDye = PlayerType.GetField("dye", BindingFlags.Public | BindingFlags.Instance);
            PlayerHideVisibleAccessory = PlayerType.GetField("hideVisibleAccessory", BindingFlags.Public | BindingFlags.Instance);
            PlayerCurrentLoadoutIndex = PlayerType.GetField("CurrentLoadoutIndex", BindingFlags.Public | BindingFlags.Instance);
            PlayerMouseInterface = PlayerType.GetField("mouseInterface", BindingFlags.Public | BindingFlags.Instance);
            PlayerWings = PlayerType.GetField("wings", BindingFlags.Public | BindingFlags.Instance);
            PlayerWingsLogic = PlayerType.GetField("wingsLogic", BindingFlags.Public | BindingFlags.Instance);
            PlayerGetExtraSlots = PlayerType.GetMethod("GetAmountOfExtraAccessorySlotsToShow", BindingFlags.Public | BindingFlags.Instance);

            PlayerGrantPrefixBenefits = PlayerType.GetMethod("GrantPrefixBenefits", BindingFlags.NonPublic | BindingFlags.Instance);
            PlayerGrantArmorBenefits = PlayerType.GetMethod("GrantArmorBenefits", BindingFlags.NonPublic | BindingFlags.Instance);
            PlayerApplyEquipFunctional = PlayerType.GetMethod("ApplyEquipFunctional", BindingFlags.NonPublic | BindingFlags.Instance);
            PlayerApplyEquipVanity = PlayerType.GetMethod("ApplyEquipVanity", BindingFlags.NonPublic | BindingFlags.Instance);
            PlayerUpdateVisibleAccessories = PlayerType.GetMethod("UpdateVisibleAccessories", BindingFlags.NonPublic | BindingFlags.Instance);

            // Find XNA types from loaded assemblies (can't use Assembly.Load for XNA)
            Type spriteBatchType = null, vector2Type = null, colorType = null;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                spriteBatchType = spriteBatchType ?? asm.GetType("Microsoft.Xna.Framework.Graphics.SpriteBatch");
                vector2Type = vector2Type ?? asm.GetType("Microsoft.Xna.Framework.Vector2");
                colorType = colorType ?? asm.GetType("Microsoft.Xna.Framework.Color");
                if (spriteBatchType != null && vector2Type != null && colorType != null) break;
            }

            if (ItemSlotType != null && spriteBatchType != null && ItemType != null && vector2Type != null && colorType != null)
            {
                var itemArrayType = ItemType.MakeArrayType();
                ItemSlotDrawArray = ItemSlotType.GetMethod("Draw", new Type[]
                {
                    spriteBatchType, itemArrayType, typeof(int), typeof(int), vector2Type, colorType
                });
            }

            if (TextureAssetsType != null)
            {
                TickOnField = TextureAssetsType.GetField("InventoryTickOn", BindingFlags.Public | BindingFlags.Static);
                TickOffField = TextureAssetsType.GetField("InventoryTickOff", BindingFlags.Public | BindingFlags.Static);
            }

            if (SoundEngineType != null)
            {
                foreach (var m in SoundEngineType.GetMethods(BindingFlags.Public | BindingFlags.Static))
                {
                    if (m.Name != "PlaySound") continue;
                    var parms = m.GetParameters();
                    if (parms.Length >= 1 && parms[0].ParameterType == typeof(int))
                    {
                        PlaySoundMethod = m;
                        break;
                    }
                }
            }

            ItemTypeField = ItemType?.GetField("type", BindingFlags.Public | BindingFlags.Instance);
            ItemWingSlotField = ItemType?.GetField("wingSlot", BindingFlags.Public | BindingFlags.Instance);

            LogReflectionStatus();
        }

        private void LogReflectionStatus()
        {
            int found = 0, missing = 0;
            void Check(string name, object val) { if (val != null) found++; else { missing++; _log.Error($"[ExtraSlots] Missing: {name}"); } }

            Check("MainType", MainType);
            Check("PlayerType", PlayerType);
            Check("ItemType", ItemType);
            Check("ItemSlotType", ItemSlotType);
            Check("MainPlayerInventory", MainPlayerInventory);
            Check("MainEquipPage", MainEquipPage);
            Check("MainMH", MainMH);
            Check("MainMouseItem", MainMouseItem);
            Check("MainSpriteBatch", MainSpriteBatch);
            Check("PlayerArmor", PlayerArmor);
            Check("PlayerGrantPrefixBenefits", PlayerGrantPrefixBenefits);
            Check("PlayerApplyEquipFunctional", PlayerApplyEquipFunctional);
            Check("PlayerGetExtraSlots", PlayerGetExtraSlots);
            Check("ItemSlotDrawArray", ItemSlotDrawArray);
            Check("TickOnField", TickOnField);
            Check("PlaySoundMethod", PlaySoundMethod);

            _log.Info($"[ExtraSlots] Reflection: {found} found, {missing} missing");
        }

        private void ClearReflectionCache()
        {
            MainType = null; PlayerType = null; ItemType = null; ItemSlotType = null;
            SoundEngineType = null; TextureAssetsType = null;
            MainPlayerInventory = null; MainEquipPage = null; MainMyPlayer = null;
            MainPlayer = null; MainMouseItem = null; MainSpriteBatch = null;
            MainScreenWidth = null; MainScreenHeight = null; MainMH = null;
            MainMouseX = null; MainMouseY = null; MainMouseLeft = null;
            MainMouseLeftRelease = null; MainMouseRight = null; MainMouseRightRelease = null;
            MainInventoryScale = null; MainIngameOptionsWindow = null; MainInFancyUI = null;
            MainHoverItemName = null; MainMouseText = null;
            PlayerArmor = null; PlayerDye = null; PlayerHideVisibleAccessory = null;
            PlayerCurrentLoadoutIndex = null;
            PlayerMouseInterface = null; PlayerWings = null; PlayerWingsLogic = null;
            PlayerGetExtraSlots = null;
            PlayerGrantPrefixBenefits = null; PlayerGrantArmorBenefits = null;
            PlayerApplyEquipFunctional = null; PlayerApplyEquipVanity = null;
            PlayerUpdateVisibleAccessories = null;
            ItemSlotDrawArray = null;
            TickOnField = null; TickOffField = null;
            PlaySoundMethod = null; ItemTypeField = null; ItemWingSlotField = null;
        }
    }
}
