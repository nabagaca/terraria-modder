using System;
using System.Reflection;
using HarmonyLib;
using TerrariaModder.Core.Logging;

namespace ExtraSlots
{
    /// <summary>
    /// Harmony postfix on Main.DrawInterface_16_MapOrMinimap that pushes
    /// Main.mH upward to make room for extra slots + wing slot below vanilla's
    /// equip panel. This matches vanilla's own approach when demon heart +
    /// master mode slots are added.
    /// </summary>
    internal static class PanelShiftPatch
    {
        private static ILogger _log;
        private static bool _wingSlotChecked;
        private static FieldInfo _wingSlotEnabledField;

        public static void Apply(Harmony harmony, ILogger log)
        {
            _log = log;

            var method = Mod.MainType.GetMethod("DrawInterface_16_MapOrMinimap",
                BindingFlags.NonPublic | BindingFlags.Instance);

            if (method == null)
            {
                _log.Error("[PanelShiftPatch] Could not find DrawInterface_16_MapOrMinimap");
                return;
            }

            var postfix = typeof(PanelShiftPatch).GetMethod(nameof(Postfix),
                BindingFlags.NonPublic | BindingFlags.Static);
            harmony.Patch(method, postfix: new HarmonyMethod(postfix));
            _log.Info("[PanelShiftPatch] DrawInterface_16_MapOrMinimap patched");
        }

        private static void Postfix()
        {
            if (Mod.MainMH == null || Mod.MainScreenHeight == null) return;

            try
            {
                // Count how many extra rows we need
                int extraRows = 0;

                // ExtraSlots rows
                if (Mod.Enabled && SlotState.Initialized)
                    extraRows += SlotState.SlotCount;

                // WingSlot row (if mod is loaded and enabled)
                if (IsWingSlotActive())
                    extraRows++;

                if (extraRows == 0) return;

                int mH = (int)Mod.MainMH.GetValue(null);
                int screenHeight = (int)Mod.MainScreenHeight.GetValue(null);
                int rowHeight = (int)(56 * 0.85f); // 47px

                // Get vanilla extra slot count (demon heart + master mode)
                int vanillaExtraSlots = 0;
                if (Mod.PlayerGetExtraSlots != null && Mod.MainMyPlayer != null && Mod.MainPlayer != null)
                {
                    try
                    {
                        int myPlayer = (int)Mod.MainMyPlayer.GetValue(null);
                        var players = (Array)Mod.MainPlayer.GetValue(null);
                        if (players != null)
                        {
                            var player = players.GetValue(myPlayer);
                            if (player != null)
                                vanillaExtraSlots = (int)Mod.PlayerGetExtraSlots.Invoke(player, null);
                        }
                    }
                    catch { }
                }

                int lastVanillaSlotIndex = 7 + vanillaExtraSlots;
                // Must match DrawPatches: firstExtraY = 174 + mH + (N+1)*rowHeight + ACCESSORY_OFFSET(8)
                int firstExtraY = 174 + mH + (lastVanillaSlotIndex + 1) * rowHeight + 8;
                int ourBottom = firstExtraY + extraRows * rowHeight;

                if (ourBottom <= screenHeight - 4) return; // everything fits

                int overflow = ourBottom - (screenHeight - 4);
                int newMH = mH - overflow;

                // Don't push the panel off the top of the screen
                // num20 = 174 + mH, so num20 >= 10 means mH >= -164
                if (newMH < -164)
                    newMH = -164;

                Mod.MainMH.SetValue(null, newMH);
            }
            catch { }
        }

        private static bool IsWingSlotActive()
        {
            if (!_wingSlotChecked)
            {
                _wingSlotChecked = true;
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    var modType = asm.GetType("WingSlot.Mod");
                    if (modType != null)
                    {
                        _wingSlotEnabledField = modType.GetField("Enabled",
                            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                        break;
                    }
                }
            }

            if (_wingSlotEnabledField == null) return false;

            try
            {
                return (bool)_wingSlotEnabledField.GetValue(null);
            }
            catch { return false; }
        }
    }
}
