using System;
using System.Reflection;
using HarmonyLib;
using TerrariaModder.Core.Logging;

namespace ExtraSlots
{
    /// <summary>
    /// Harmony postfixes on Player.UpdateEquips and Player.UpdateVisibleAccessories
    /// to apply stats/effects from extra accessory slots.
    /// Includes wing detection — sets Player.wings/wingsLogic for wing items.
    /// </summary>
    internal static class EquipEffectPatches
    {
        private static ILogger _log;

        public static void Apply(Harmony harmony, ILogger log)
        {
            _log = log;

            var updateEquips = Mod.PlayerType.GetMethod("UpdateEquips", BindingFlags.Public | BindingFlags.Instance);
            if (updateEquips != null)
            {
                var postfix = typeof(EquipEffectPatches).GetMethod(nameof(UpdateEquips_Postfix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(updateEquips, postfix: new HarmonyMethod(postfix));
                _log.Info("[EquipEffectPatches] UpdateEquips patched");
            }
            else
            {
                _log.Error("[EquipEffectPatches] Could not find Player.UpdateEquips");
            }

            if (Mod.PlayerUpdateVisibleAccessories != null)
            {
                var postfix = typeof(EquipEffectPatches).GetMethod(nameof(UpdateVisibleAccessories_Postfix), BindingFlags.NonPublic | BindingFlags.Static);
                harmony.Patch(Mod.PlayerUpdateVisibleAccessories, postfix: new HarmonyMethod(postfix));
                _log.Info("[EquipEffectPatches] UpdateVisibleAccessories patched");
            }
            else
            {
                _log.Error("[EquipEffectPatches] Could not find Player.UpdateVisibleAccessories");
            }
        }

        private static void UpdateEquips_Postfix(object __instance, int i)
        {
            if (!Mod.Enabled || !SlotState.Initialized) return;

            try
            {
                int myPlayer = (int)Mod.MainMyPlayer.GetValue(null);
                if (i != myPlayer) return;

                for (int s = 0; s < SlotState.SlotCount; s++)
                {
                    var item = SlotState.ExtraFunctional[s];
                    if (SlotState.IsAir(item)) continue;

                    ApplyAccessoryEffects(__instance, item, SlotState.ExtraHide[s]);
                }
            }
            catch (Exception ex)
            {
                _log?.Error($"[EquipEffectPatches] UpdateEquips error: {ex.Message}");
            }
        }

        private static void ApplyAccessoryEffects(object player, object item, bool hidden)
        {
            if (SlotState.IsAccessory(item))
            {
                Mod.PlayerGrantPrefixBenefits?.Invoke(player, new[] { item });
            }

            Mod.PlayerGrantArmorBenefits?.Invoke(player, new[] { item });

            // Wing detection — vanilla handles this separately from ApplyEquipFunctional
            if (Mod.ItemWingSlotField != null && Mod.PlayerWingsLogic != null)
            {
                sbyte wingSlotValue = (sbyte)Mod.ItemWingSlotField.GetValue(item);
                if (wingSlotValue > 0)
                {
                    Mod.PlayerWingsLogic.SetValue(player, (int)wingSlotValue);
                    if (!hidden && Mod.PlayerWings != null)
                        Mod.PlayerWings.SetValue(player, (int)wingSlotValue);
                }
            }

            if (Mod.PlayerApplyEquipFunctional != null && Mod.PlayerHideVisibleAccessory != null)
            {
                var hideArr = (bool[])Mod.PlayerHideVisibleAccessory.GetValue(player);
                if (hideArr != null && hideArr.Length > 3)
                {
                    bool originalHide = hideArr[3];
                    hideArr[3] = hidden;
                    try
                    {
                        Mod.PlayerApplyEquipFunctional.Invoke(player, new object[] { 3, item });
                    }
                    finally
                    {
                        hideArr[3] = originalHide;
                    }
                }
            }
        }

        private static void UpdateVisibleAccessories_Postfix(object __instance)
        {
            if (!Mod.Enabled || !SlotState.Initialized) return;

            try
            {
                for (int s = 0; s < SlotState.SlotCount; s++)
                {
                    var vanityItem = SlotState.ExtraVanity[s];
                    if (SlotState.IsAir(vanityItem)) continue;

                    Mod.PlayerApplyEquipVanity?.Invoke(__instance, new object[] { 3, vanityItem });
                }
            }
            catch (Exception ex)
            {
                _log?.Error($"[EquipEffectPatches] UpdateVisibleAccessories error: {ex.Message}");
            }
        }
    }
}
