using System;
using System.Reflection;
using TerrariaModder.Core.Logging;
using TerrariaModder.Core.UI;

namespace ExtraSlots
{
    /// <summary>
    /// Draws extra accessory slots via FrameEvents.OnUIOverlay.
    /// Matches vanilla's exact equip panel layout (single column).
    /// PanelShiftPatch handles overflow by pushing the entire panel up via Main.mH.
    /// </summary>
    internal static class DrawPatches
    {
        private const int SLOT_SIZE = 56;
        private const float EQUIP_SCALE = 0.85f;
        private const int ACCESSORY_OFFSET = 8;
        private const int SOUND_GRAB = 7;

        private static bool _anySlotHovered;
        private static int _debugFrames = 120;
        internal static ILogger _log;

        // Cached XNA types for ItemSlot.Draw
        private static Type _vector2Type;
        private static Type _colorType;
        private static object _whiteColor;

        // Cross-mod: WingSlot position detection
        private static bool _wingSlotSearched;
        private static PropertyInfo _wingSlotRowBottomProp;
        private static PropertyInfo _wingSlotIsDrawingProp;

        public static void OnUIOverlay()
        {
            if (!Mod.Enabled || !SlotState.Initialized) return;
            if (SlotState.SlotCount == 0) return;

            try
            {
                if (Mod.MainPlayerInventory == null || Mod.MainEquipPage == null) return;
                bool inventoryOpen = (bool)Mod.MainPlayerInventory.GetValue(null);
                int equipPage = (int)Mod.MainEquipPage.GetValue(null);
                if (!inventoryOpen || equipPage != 0) return;

                if (Mod.MainIngameOptionsWindow != null && (bool)Mod.MainIngameOptionsWindow.GetValue(null)) return;
                if (Mod.MainInFancyUI != null && (bool)Mod.MainInFancyUI.GetValue(null)) return;

                int screenWidth = (int)Mod.MainScreenWidth.GetValue(null);
                int screenHeight = (int)Mod.MainScreenHeight.GetValue(null);
                int mH = Mod.MainMH != null ? (int)Mod.MainMH.GetValue(null) : 0;

                int myPlayer = (int)Mod.MainMyPlayer.GetValue(null);
                var players = (Array)Mod.MainPlayer.GetValue(null);
                var player = players.GetValue(myPlayer);

                int vanillaExtraSlots = 0;
                if (Mod.PlayerGetExtraSlots != null)
                    vanillaExtraSlots = (int)Mod.PlayerGetExtraSlots.Invoke(player, null);

                int rowHeight = (int)(SLOT_SIZE * EQUIP_SCALE);

                // Vanilla's last visible slot index (3-7 base + extras at 8,9)
                int lastVanillaSlotIndex = 7 + vanillaExtraSlots;

                // Our first row Y = right after vanilla's last slot (or after wing slot if active)
                int baseY = 174 + mH;
                int firstExtraY = baseY + (lastVanillaSlotIndex + 1) * rowHeight + ACCESSORY_OFFSET;

                // If WingSlot mod is drawing, position below its row
                int wingSlotBottom = GetWingSlotBottom();
                if (wingSlotBottom > 0 && wingSlotBottom > firstExtraY)
                    firstExtraY = wingSlotBottom;

                // Fixed column X positions — same as vanilla (no side-shift)
                int colFunctional = screenWidth - 92;
                int colVanity = screenWidth - 139;
                int colDye = screenWidth - 186;
                int eyeX = screenWidth - 58;

                if (_debugFrames > 0)
                {
                    _debugFrames--;
                    if (_debugFrames == 119)
                        _log?.Info($"[DrawPatches] screenW={screenWidth} screenH={screenHeight} mH={mH} vanillaExtra={vanillaExtraSlots} firstExtraY={firstExtraY} slotCount={SlotState.SlotCount}");
                }

                _anySlotHovered = false;

                for (int s = 0; s < SlotState.SlotCount; s++)
                {
                    int slotY = firstExtraY + s * rowHeight;

                    // Skip slots that are off-screen (PanelShiftPatch couldn't push up enough)
                    if (slotY + rowHeight > screenHeight) break;

                    DrawSingleSlot(colFunctional, slotY, SlotState.ExtraFunctional[s], 10);
                    DrawSingleSlot(colVanity, slotY, SlotState.ExtraVanity[s], 11);
                    DrawSingleSlot(colDye, slotY, SlotState.ExtraDye[s], 12);
                    DrawEyeIcon(eyeX, slotY, SlotState.ExtraHide[s]);

                    var funcRef = SlotState.ExtraFunctional[s];
                    var vanRef = SlotState.ExtraVanity[s];
                    var dyeRef = SlotState.ExtraDye[s];

                    HandleSlotClick(colFunctional, slotY, ref funcRef, player, ClickMode.Accessory, s);
                    HandleSlotClick(colVanity, slotY, ref vanRef, player, ClickMode.AccessoryVanity, s);
                    HandleSlotClick(colDye, slotY, ref dyeRef, player, ClickMode.Dye, s);

                    SlotState.ExtraFunctional[s] = funcRef;
                    SlotState.ExtraVanity[s] = vanRef;
                    SlotState.ExtraDye[s] = dyeRef;

                    bool hideRef = SlotState.ExtraHide[s];
                    HandleEyeClick(eyeX, slotY, ref hideRef);
                    SlotState.ExtraHide[s] = hideRef;
                }

                if (_anySlotHovered && Mod.PlayerMouseInterface != null)
                {
                    Mod.PlayerMouseInterface.SetValue(player, true);
                }
            }
            catch (Exception ex)
            {
                if (_debugFrames > 0)
                    _log?.Error($"[DrawPatches] OnUIOverlay error: {ex.Message}\n{ex.StackTrace}");
            }
        }

        private static int GetWingSlotBottom()
        {
            if (!_wingSlotSearched)
            {
                _wingSlotSearched = true;
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    var drawType = asm.GetType("WingSlot.WingDrawPatches");
                    if (drawType != null)
                    {
                        _wingSlotRowBottomProp = drawType.GetProperty("WingSlotRowBottom", BindingFlags.Public | BindingFlags.Static);
                        _wingSlotIsDrawingProp = drawType.GetProperty("IsDrawing", BindingFlags.Public | BindingFlags.Static);
                        break;
                    }
                }
            }

            if (_wingSlotIsDrawingProp == null || _wingSlotRowBottomProp == null) return 0;

            try
            {
                bool isDrawing = (bool)_wingSlotIsDrawingProp.GetValue(null);
                if (!isDrawing) return 0;
                return (int)_wingSlotRowBottomProp.GetValue(null);
            }
            catch { return 0; }
        }

        private static void DrawSingleSlot(int x, int y, object item, int context)
        {
            if (Mod.ItemSlotDrawArray == null || Mod.MainSpriteBatch == null || Mod.MainInventoryScale == null) return;

            float prevScale = (float)Mod.MainInventoryScale.GetValue(null);
            Mod.MainInventoryScale.SetValue(null, EQUIP_SCALE);
            try
            {
                EnsureSlotBuffer();
                _slotBuffer.SetValue(item, 0);

                EnsureXnaTypesCache();
                var position = Activator.CreateInstance(_vector2Type, new object[] { (float)x, (float)y });

                var spriteBatch = Mod.MainSpriteBatch.GetValue(null);
                Mod.ItemSlotDrawArray.Invoke(null, new object[] { spriteBatch, _slotBuffer, context, 0, position, _whiteColor });
            }
            catch (Exception) { }
            finally
            {
                Mod.MainInventoryScale.SetValue(null, prevScale);
            }
        }

        private static Array _slotBuffer;
        private static void EnsureSlotBuffer()
        {
            if (_slotBuffer == null)
                _slotBuffer = Array.CreateInstance(Mod.ItemType, 1);
        }

        private static void EnsureXnaTypesCache()
        {
            if (_vector2Type != null) return;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                _vector2Type = _vector2Type ?? asm.GetType("Microsoft.Xna.Framework.Vector2");
                _colorType = _colorType ?? asm.GetType("Microsoft.Xna.Framework.Color");
                if (_vector2Type != null && _colorType != null) break;
            }
            if (_colorType != null)
                _whiteColor = _colorType.GetProperty("White", BindingFlags.Public | BindingFlags.Static)?.GetValue(null)
                    ?? Activator.CreateInstance(_colorType);
        }

        private enum ClickMode { Accessory, AccessoryVanity, Dye }

        private static void SetHoverText(string text)
        {
            if (Mod.MainHoverItemName != null && Mod.MainMouseText != null)
            {
                Mod.MainHoverItemName.SetValue(null, text);
                Mod.MainMouseText.SetValue(null, true);
            }
        }

        private static string GetSlotTooltip(ClickMode mode, int slotIndex)
        {
            switch (mode)
            {
                case ClickMode.Accessory: return "Extra Slot " + (slotIndex + 1);
                case ClickMode.AccessoryVanity: return "Extra Vanity " + (slotIndex + 1);
                case ClickMode.Dye: return "Extra Dye " + (slotIndex + 1);
                default: return "";
            }
        }

        private static void HandleSlotClick(int x, int y, ref object slotItem, object player, ClickMode mode, int slotIndex)
        {
            if (Mod.MainMouseX == null || Mod.MainMouseY == null) return;

            int mouseX = (int)Mod.MainMouseX.GetValue(null);
            int mouseY = (int)Mod.MainMouseY.GetValue(null);
            int slotSize = (int)(SLOT_SIZE * EQUIP_SCALE);

            if (mouseX < x || mouseX >= x + slotSize || mouseY < y || mouseY >= y + slotSize)
                return;

            _anySlotHovered = true;

            if (SlotState.IsAir(slotItem))
                SetHoverText(GetSlotTooltip(mode, slotIndex));

            bool mouseLeft = (bool)Mod.MainMouseLeft.GetValue(null);
            bool mouseLeftRelease = (bool)Mod.MainMouseLeftRelease.GetValue(null);

            if (mouseLeft && mouseLeftRelease)
            {
                Mod.MainMouseLeftRelease.SetValue(null, false);

                var mouseItem = Mod.MainMouseItem.GetValue(null);
                bool mouseIsAir = SlotState.IsAir(mouseItem);

                if (mouseIsAir && SlotState.IsAir(slotItem))
                    return;

                if (!mouseIsAir && !ValidateItem(mouseItem, mode, player, slotIndex))
                {
                    _log?.Info($"[DrawPatches] Validation failed: mode={mode} itemType={SlotState.GetItemType(mouseItem)} isAccessory={SlotState.IsAccessory(mouseItem)} wingSlot={SlotState.GetWingSlot(mouseItem)}");
                    return;
                }

                var temp = slotItem;
                slotItem = mouseIsAir ? SlotState.CreateAirItem() : mouseItem;
                Mod.MainMouseItem.SetValue(null, SlotState.IsAir(temp) ? SlotState.CreateAirItem() : temp);

                PlayEquipSound();
            }

            bool mouseRight = (bool)Mod.MainMouseRight.GetValue(null);
            bool mouseRightRelease = (bool)Mod.MainMouseRightRelease.GetValue(null);

            if (mouseRight && mouseRightRelease && !SlotState.IsAir(slotItem))
            {
                var mouseItem = Mod.MainMouseItem.GetValue(null);
                if (SlotState.IsAir(mouseItem))
                {
                    Mod.MainMouseRightRelease.SetValue(null, false);
                    Mod.MainMouseItem.SetValue(null, slotItem);
                    slotItem = SlotState.CreateAirItem();
                    PlayEquipSound();
                }
            }
        }

        private static bool ValidateItem(object item, ClickMode mode, object player, int slotIndex)
        {
            switch (mode)
            {
                case ClickMode.Accessory:
                    if (!SlotState.IsAccessory(item)) return false;
                    if (IsDuplicateAccessory(item, player, slotIndex)) return false;
                    // Wing uniqueness: only one wing allowed across all slots
                    if (SlotState.GetWingSlot(item) > 0 && IsAnyWingEquippedElsewhere(player, slotIndex))
                        return false;
                    return true;

                case ClickMode.AccessoryVanity:
                    return SlotState.IsAccessory(item);

                case ClickMode.Dye:
                    return true;

                default:
                    return true;
            }
        }

        private static bool IsDuplicateAccessory(object item, object player, int excludeSlotIndex)
        {
            if (Mod.ItemTypeField == null) return false;
            int itemType = (int)Mod.ItemTypeField.GetValue(item);
            if (itemType <= 0) return false;

            var armor = (Array)Mod.PlayerArmor.GetValue(player);
            if (armor != null)
            {
                for (int i = 3; i < 10; i++)
                {
                    var equipped = armor.GetValue(i);
                    if (!SlotState.IsAir(equipped) && (int)Mod.ItemTypeField.GetValue(equipped) == itemType)
                        return true;
                }
            }

            for (int i = 0; i < SlotState.SlotCount; i++)
            {
                if (i == excludeSlotIndex) continue;
                if (!SlotState.IsAir(SlotState.ExtraFunctional[i]) && SlotState.GetItemType(SlotState.ExtraFunctional[i]) == itemType)
                    return true;
            }

            // Cross-mod: check WingSlot if loaded
            if (CrossModCompat.GetWingSlotEquippedType() == itemType)
                return true;

            return false;
        }

        /// <summary>
        /// Returns true if any wing is equipped anywhere (vanilla, extra slots, wing slot)
        /// EXCLUDING the specified extra slot index.
        /// </summary>
        private static bool IsAnyWingEquippedElsewhere(object player, int excludeSlotIndex)
        {
            // Check vanilla armor slots 3-9
            var armor = (Array)Mod.PlayerArmor.GetValue(player);
            if (armor != null && Mod.ItemWingSlotField != null)
            {
                for (int i = 3; i < 10; i++)
                {
                    var equipped = armor.GetValue(i);
                    if (!SlotState.IsAir(equipped))
                    {
                        sbyte ws = (sbyte)Mod.ItemWingSlotField.GetValue(equipped);
                        if (ws > 0) return true;
                    }
                }
            }

            // Check other extra slots
            for (int i = 0; i < SlotState.SlotCount; i++)
            {
                if (i == excludeSlotIndex) continue;
                if (!SlotState.IsAir(SlotState.ExtraFunctional[i]) && SlotState.GetWingSlot(SlotState.ExtraFunctional[i]) > 0)
                    return true;
            }

            // Cross-mod: check WingSlot mod
            if (CrossModCompat.IsWingSlotOccupied())
                return true;

            return false;
        }

        private static void DrawEyeIcon(int iconX, int slotY, bool hideFlag)
        {
            if (Mod.TickOnField == null || Mod.TickOffField == null) return;

            try
            {
                int iconY = slotY + (int)(SLOT_SIZE * EQUIP_SCALE * 0.25f);

                var tickAsset = hideFlag ? Mod.TickOffField.GetValue(null) : Mod.TickOnField.GetValue(null);
                if (tickAsset == null) return;

                var valueProp = tickAsset.GetType().GetProperty("Value");
                var texture = valueProp?.GetValue(tickAsset);
                if (texture == null) return;

                var widthProp = texture.GetType().GetProperty("Width");
                var heightProp = texture.GetType().GetProperty("Height");
                int iconW = widthProp != null ? (int)widthProp.GetValue(texture) : 16;
                int iconH = heightProp != null ? (int)heightProp.GetValue(texture) : 16;

                UIRenderer.DrawTexture(texture, iconX, iconY, iconW, iconH, (byte)178);
            }
            catch (Exception)
            {
                // Silent
            }
        }

        private static void HandleEyeClick(int iconX, int slotY, ref bool hideFlag)
        {
            if (Mod.TickOnField == null || Mod.TickOffField == null) return;
            if (Mod.MainMouseX == null || Mod.MainMouseY == null) return;

            try
            {
                int iconY = slotY + (int)(SLOT_SIZE * EQUIP_SCALE * 0.25f);

                var tickAsset = hideFlag ? Mod.TickOffField.GetValue(null) : Mod.TickOnField.GetValue(null);
                if (tickAsset == null) return;

                var valueProp = tickAsset.GetType().GetProperty("Value");
                var texture = valueProp?.GetValue(tickAsset);
                if (texture == null) return;

                var widthProp = texture.GetType().GetProperty("Width");
                var heightProp = texture.GetType().GetProperty("Height");
                int iconW = widthProp != null ? (int)widthProp.GetValue(texture) : 16;
                int iconH = heightProp != null ? (int)heightProp.GetValue(texture) : 16;

                int mouseX = (int)Mod.MainMouseX.GetValue(null);
                int mouseY = (int)Mod.MainMouseY.GetValue(null);

                if (mouseX >= iconX && mouseX < iconX + iconW && mouseY >= iconY && mouseY < iconY + iconH)
                {
                    _anySlotHovered = true;

                    bool mouseLeft = (bool)Mod.MainMouseLeft.GetValue(null);
                    bool mouseLeftRelease = (bool)Mod.MainMouseLeftRelease.GetValue(null);

                    var mouseItem = Mod.MainMouseItem.GetValue(null);
                    if (mouseLeft && mouseLeftRelease && SlotState.IsAir(mouseItem))
                    {
                        Mod.MainMouseLeftRelease.SetValue(null, false);
                        hideFlag = !hideFlag;
                    }
                }
            }
            catch (Exception)
            {
                // Silent
            }
        }

        private static void PlayEquipSound()
        {
            if (Mod.PlaySoundMethod == null) return;
            try
            {
                var parms = Mod.PlaySoundMethod.GetParameters();
                if (parms.Length == 6)
                    Mod.PlaySoundMethod.Invoke(null, new object[] { SOUND_GRAB, -1, -1, 1, 1f, 0f });
                else if (parms.Length >= 1)
                {
                    var args = new object[parms.Length];
                    args[0] = SOUND_GRAB;
                    for (int i = 1; i < args.Length; i++)
                        args[i] = parms[i].HasDefaultValue ? parms[i].DefaultValue : null;
                    Mod.PlaySoundMethod.Invoke(null, args);
                }
            }
            catch (Exception) { }
        }
    }
}
