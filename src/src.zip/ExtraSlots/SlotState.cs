using System;
using System.Reflection;
using TerrariaModder.Core.Logging;

namespace ExtraSlots
{
    /// <summary>
    /// Static state for extra accessory slots — parallel arrays maintained alongside vanilla's Player.armor[20].
    /// All items are created via reflection as Terraria Item instances.
    /// Per-loadout copies mirror vanilla's EquipmentLoadout system (3 loadouts).
    /// </summary>
    internal static class SlotState
    {
        private static ILogger _log;
        private static Type _itemType;
        private static FieldInfo _typeField;
        private static FieldInfo _stackField;
        private static FieldInfo _prefixField;
        private static FieldInfo _accessoryField;
        private static FieldInfo _wingSlotField;
        private static MethodInfo _setDefaultsMethod;
        private static PropertyInfo _isAirProp;

        // Extra accessory slots (parallel arrays)
        public static object[] ExtraFunctional;
        public static object[] ExtraVanity;
        public static object[] ExtraDye;
        public static bool[] ExtraHide;

        // Per-loadout storage (3 loadouts)
        public static object[][] LoadoutExtraFunctional;
        public static object[][] LoadoutExtraVanity;
        public static object[][] LoadoutExtraDye;
        public static bool[][] LoadoutExtraHide;

        public static int SlotCount { get; private set; }
        public static bool Initialized { get; private set; }

        public static void InitReflection(ILogger log)
        {
            _log = log;
            _itemType = Type.GetType("Terraria.Item, Terraria")
                ?? Assembly.Load("Terraria").GetType("Terraria.Item");

            if (_itemType == null)
            {
                _log?.Error("[SlotState] Could not find Terraria.Item type");
                return;
            }

            _typeField = _itemType.GetField("type", BindingFlags.Public | BindingFlags.Instance);
            _stackField = _itemType.GetField("stack", BindingFlags.Public | BindingFlags.Instance);
            _prefixField = _itemType.GetField("prefix", BindingFlags.Public | BindingFlags.Instance);
            _accessoryField = _itemType.GetField("accessory", BindingFlags.Public | BindingFlags.Instance);
            _wingSlotField = _itemType.GetField("wingSlot", BindingFlags.Public | BindingFlags.Instance);
            _isAirProp = _itemType.GetProperty("IsAir", BindingFlags.Public | BindingFlags.Instance);
            _setDefaultsMethod = _itemType.GetMethod("SetDefaults", new Type[] { typeof(int) });

            _log?.Info("[SlotState] Reflection initialized");
        }

        public static void Initialize(int count)
        {
            SlotCount = Math.Max(0, count);

            ExtraFunctional = new object[SlotCount];
            ExtraVanity = new object[SlotCount];
            ExtraDye = new object[SlotCount];
            ExtraHide = new bool[SlotCount];
            for (int i = 0; i < SlotCount; i++)
            {
                ExtraFunctional[i] = CreateAirItem();
                ExtraVanity[i] = CreateAirItem();
                ExtraDye[i] = CreateAirItem();
            }

            LoadoutExtraFunctional = new object[3][];
            LoadoutExtraVanity = new object[3][];
            LoadoutExtraDye = new object[3][];
            LoadoutExtraHide = new bool[3][];

            for (int l = 0; l < 3; l++)
            {
                LoadoutExtraFunctional[l] = new object[SlotCount];
                LoadoutExtraVanity[l] = new object[SlotCount];
                LoadoutExtraDye[l] = new object[SlotCount];
                LoadoutExtraHide[l] = new bool[SlotCount];
                for (int i = 0; i < SlotCount; i++)
                {
                    LoadoutExtraFunctional[l][i] = CreateAirItem();
                    LoadoutExtraVanity[l][i] = CreateAirItem();
                    LoadoutExtraDye[l][i] = CreateAirItem();
                }
            }

            Initialized = true;
            _log?.Info($"[SlotState] Initialized with {SlotCount} extra slots");
        }

        public static object[] Resize(int newCount)
        {
            newCount = Math.Max(0, newCount);
            if (newCount == SlotCount) return Array.Empty<object>();

            var displaced = new System.Collections.Generic.List<object>();

            if (newCount < SlotCount)
            {
                for (int i = newCount; i < SlotCount; i++)
                {
                    if (!IsAir(ExtraFunctional[i])) displaced.Add(ExtraFunctional[i]);
                    if (!IsAir(ExtraVanity[i])) displaced.Add(ExtraVanity[i]);
                    if (!IsAir(ExtraDye[i])) displaced.Add(ExtraDye[i]);
                }
            }

            ExtraFunctional = ResizeArray(ExtraFunctional, newCount);
            ExtraVanity = ResizeArray(ExtraVanity, newCount);
            ExtraDye = ResizeArray(ExtraDye, newCount);
            Array.Resize(ref ExtraHide, newCount);

            for (int l = 0; l < 3; l++)
            {
                if (newCount < LoadoutExtraFunctional[l].Length)
                {
                    for (int i = newCount; i < LoadoutExtraFunctional[l].Length; i++)
                    {
                        if (!IsAir(LoadoutExtraFunctional[l][i])) displaced.Add(LoadoutExtraFunctional[l][i]);
                        if (!IsAir(LoadoutExtraVanity[l][i])) displaced.Add(LoadoutExtraVanity[l][i]);
                        if (!IsAir(LoadoutExtraDye[l][i])) displaced.Add(LoadoutExtraDye[l][i]);
                    }
                }
                LoadoutExtraFunctional[l] = ResizeArray(LoadoutExtraFunctional[l], newCount);
                LoadoutExtraVanity[l] = ResizeArray(LoadoutExtraVanity[l], newCount);
                LoadoutExtraDye[l] = ResizeArray(LoadoutExtraDye[l], newCount);
                Array.Resize(ref LoadoutExtraHide[l], newCount);
            }

            SlotCount = newCount;
            _log?.Info($"[SlotState] Resized to {newCount} extra slots, {displaced.Count} items displaced");
            return displaced.ToArray();
        }

        public static void SwapLoadout(int fromLoadout, int toLoadout)
        {
            if (fromLoadout < 0 || fromLoadout >= 3 || toLoadout < 0 || toLoadout >= 3) return;

            for (int i = 0; i < SlotCount && i < LoadoutExtraFunctional[fromLoadout].Length; i++)
            {
                LoadoutExtraFunctional[fromLoadout][i] = ExtraFunctional[i];
                LoadoutExtraVanity[fromLoadout][i] = ExtraVanity[i];
                LoadoutExtraDye[fromLoadout][i] = ExtraDye[i];
                LoadoutExtraHide[fromLoadout][i] = ExtraHide[i];
            }

            for (int i = 0; i < SlotCount; i++)
            {
                if (i < LoadoutExtraFunctional[toLoadout].Length)
                {
                    ExtraFunctional[i] = LoadoutExtraFunctional[toLoadout][i];
                    ExtraVanity[i] = LoadoutExtraVanity[toLoadout][i];
                    ExtraDye[i] = LoadoutExtraDye[toLoadout][i];
                    ExtraHide[i] = LoadoutExtraHide[toLoadout][i];
                }
                else
                {
                    ExtraFunctional[i] = CreateAirItem();
                    ExtraVanity[i] = CreateAirItem();
                    ExtraDye[i] = CreateAirItem();
                    ExtraHide[i] = false;
                }
            }

            _log?.Info($"[SlotState] Swapped loadout {fromLoadout} → {toLoadout}");
        }

        public static void Clear()
        {
            ExtraFunctional = null;
            ExtraVanity = null;
            ExtraDye = null;
            ExtraHide = null;
            LoadoutExtraFunctional = null;
            LoadoutExtraVanity = null;
            LoadoutExtraDye = null;
            LoadoutExtraHide = null;
            SlotCount = 0;
            Initialized = false;
        }

        // --- Item helpers ---

        public static object CreateAirItem()
        {
            if (_itemType == null) return null;
            return Activator.CreateInstance(_itemType);
        }

        public static object CreateItem(int type, int stack = 1, int prefix = 0)
        {
            var item = CreateAirItem();
            if (item == null || _setDefaultsMethod == null) return item;
            _setDefaultsMethod.Invoke(item, new object[] { type });
            if (stack > 1) _stackField?.SetValue(item, stack);
            if (prefix > 0) _prefixField?.SetValue(item, (byte)prefix);
            return item;
        }

        public static bool IsAir(object item)
        {
            if (item == null) return true;
            if (_isAirProp != null) return (bool)_isAirProp.GetValue(item);
            if (_typeField != null) return (int)_typeField.GetValue(item) == 0;
            return true;
        }

        public static int GetItemType(object item)
        {
            if (item == null || _typeField == null) return 0;
            return (int)_typeField.GetValue(item);
        }

        public static int GetItemStack(object item)
        {
            if (item == null || _stackField == null) return 0;
            return (int)_stackField.GetValue(item);
        }

        public static int GetItemPrefix(object item)
        {
            if (item == null || _prefixField == null) return 0;
            return (int)(byte)_prefixField.GetValue(item);
        }

        public static bool IsAccessory(object item)
        {
            if (item == null || _accessoryField == null) return false;
            return (bool)_accessoryField.GetValue(item);
        }

        public static int GetWingSlot(object item)
        {
            if (item == null || _wingSlotField == null) return 0;
            return (int)(sbyte)_wingSlotField.GetValue(item);
        }

        private static object[] ResizeArray(object[] arr, int newSize)
        {
            var newArr = new object[newSize];
            int copyLen = Math.Min(arr.Length, newSize);
            Array.Copy(arr, newArr, copyLen);
            for (int i = copyLen; i < newSize; i++)
                newArr[i] = CreateAirItem();
            return newArr;
        }
    }
}
